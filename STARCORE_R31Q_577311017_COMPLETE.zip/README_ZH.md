# STARCORE R31 实际签名构建候选包

本包由完整源码 2c65ca694e878fb29372e4617b940bec47841df3 构建。应用身份 com.starcore.research.r13，签名通道 EXISTING_R27，指纹 d8d8cee7f406267b2bf18fc9aef0c6ab760423cf205ccd6613dd44085bcc74e7。

源码入口：https://github.com/gtt46461-star/starcore-public-build/tree/2c65ca694e878fb29372e4617b940bec47841df3
完整快照：https://github.com/gtt46461-star/starcore-public-build/archive/2c65ca694e878fb29372e4617b940bec47841df3.zip

请以 delivery.json 的实际 APK 哈希和版本为准。构建通过不等于全部施工卡、真机持续运行或自然策略质量通过；真实状态见 ACCEPTANCE.json、EXECUTION_LEDGER.json 和独立 CI Android 产物。升级兼容性需核对设备现有应用签名；本流程没有读取用户设备的实际签名。
