package com.ethk3.novaonepro;

import java.io.*;
import java.nio.charset.*;
import java.security.*;
import java.util.*;
import org.json.JSONObject;

/** Reads one immutable archive. Never loads a manifest, member, or all part names in memory. */
public final class ReportArchiveVerifierCP12 {
    private ReportArchiveVerifierCP12() {}
    public interface Decoder {
        void decode(InputStream compressed, OutputStream raw, long expectedRawBytes,
                    ReportNativeCP4.Control control) throws Exception;
    }
    public interface PartVisitor { void part(String name, File file, long bytes, String sha256) throws Exception; }
    public static final class Receipt {
        public final String reportId, manifestSha256, scope;
        public final long compressedBytes, rawBytes;
        public final int parts, members;
        public final boolean evidenceComplete, checksComplete;
        private Receipt(String id,String sha,String scope,long bytes,long raw,int parts,int members,boolean evidence,boolean checks) {
            reportId=id;manifestSha256=sha;this.scope=scope;compressedBytes=bytes;rawBytes=raw;
            this.parts=parts;this.members=members;evidenceComplete=evidence;checksComplete=checks;
        }
    }
    /** Decoder is mandatory for a publishing proof: compressed-part SHA alone does not prove raw completeness. */
    public static Receipt verify(File directory,String expectedReportId,Decoder decoder,
                                  ReportNativeCP4.Control control,PartVisitor visitor) throws Exception {
        requireHash(expectedReportId);if(decoder==null||control==null)throw fail("REPORT_VERIFY_ARGUMENT");
        File root=directory.getCanonicalFile();if(!root.isDirectory())throw fail("REPORT_VERIFY_DIRECTORY");
        File manifest=inside(root,"manifest.jsonl");MessageDigest body=sha(),full=sha();
        int nextPart=1,members=0,memberFirst=1,memberParts=0;long compressedBytes=0,rawBytes=0;
        String activeMember=null,lastMember=null,reportId=null,scope=null;boolean footer=false,evidence=false,checks=false;
        try(LineReader lines=new LineReader(new FileInputStream(manifest),8192)) {
            byte[] bytes;int ordinal=0;
            while((bytes=lines.next())!=null) {
                checkpoint(control);ordinal++;full.update(bytes);
                JSONObject row=new JSONObject(decodeUtf8(bytes,0,bytes.length-1));String kind=row.getString("kind");
                if(footer)throw fail("REPORT_MANIFEST_AFTER_FOOTER");
                if(ordinal==1) {
                    if(!"header".equals(kind)||!"STARCORE_REPORT_CP4".equals(row.getString("format"))
                       ||!"zstd-1.5.7-window19".equals(row.getString("codec"))
                       ||row.getLong("part_bytes")!=ReportArchiveCP4.PART_BYTES)throw fail("REPORT_MANIFEST_HEADER");
                    reportId=row.getString("report_id");if(!expectedReportId.equals(reportId))throw fail("REPORT_MANIFEST_REPORT_ID");
                    body.update(bytes);continue;
                }
                if("part".equals(kind)) {
                    String name=row.getString("name"),member=row.getString("member");requireName(member);
                    String expected=String.format(Locale.ROOT,"P%06d.bin",nextPart);
                    if(nextPart>999999||!expected.equals(name))throw fail("REPORT_PART_SEQUENCE");
                    if(activeMember==null){activeMember=member;memberFirst=nextPart;memberParts=0;}
                    if(!activeMember.equals(member))throw fail("REPORT_PART_MEMBER_BOUNDARY");
                    File file=inside(root,name);long size=row.getLong("bytes");String hash=row.getString("sha256");requireHash(hash);
                    if(size<1||size>ReportArchiveCP4.PART_BYTES||!file.isFile()||file.length()!=size
                       ||!hash.equals(ReportArchiveCP4.hash(file,control)))throw fail("REPORT_PART_INTEGRITY");
                    // An earlier part in the same member must be exactly full; final part can be short.
                    if(memberParts>0&&inside(root,String.format(Locale.ROOT,"P%06d.bin",nextPart-1)).length()!=ReportArchiveCP4.PART_BYTES)
                        throw fail("REPORT_PART_SHORT_INTERIOR");
                    if(visitor!=null)visitor.part(name,file,size,hash);
                    compressedBytes=Math.addExact(compressedBytes,size);nextPart++;memberParts++;body.update(bytes);
                } else if("member".equals(kind)) {
                    String name=row.getString("name"),hash=row.getString("raw_sha256");requireName(name);requireHash(hash);
                    int first=row.getInt("first_part"),count=row.getInt("part_count");long size=row.getLong("raw_bytes");
                    if(size<0||activeMember==null||!name.equals(activeMember)||first!=memberFirst||count!=memberParts||count<1)
                        throw fail("REPORT_MEMBER_RANGE");
                    // Writer order is lexical. It makes duplicate detection bounded rather than keeping an unbounded name Set.
                    if(lastMember!=null&&lastMember.compareTo(name)>=0)throw fail("REPORT_MEMBER_NAME_ORDER");
                    CountingDigest sink=new CountingDigest(size);
                    try(InputStream source=new PartInput(root,first,count,control)) {decoder.decode(source,sink,size,control);if(source.read()!=-1)throw fail("REPORT_DECODER_TRAILING_BYTES");}
                    if(sink.count!=size||!hash.equals(hex(sink.digest.digest())))throw fail("REPORT_RAW_MEMBER_INTEGRITY");
                    rawBytes=Math.addExact(rawBytes,size);members++;lastMember=name;activeMember=null;memberParts=0;body.update(bytes);
                } else if("footer".equals(kind)) {
                    if(activeMember!=null||row.getInt("members")!=members||row.getInt("parts")!=nextPart-1
                       ||!hex(body.digest()).equals(row.getString("manifest_body_sha256")))throw fail("REPORT_MANIFEST_FOOTER");
                    scope=row.getString("scope");if(scope.length()<1||scope.length()>512)throw fail("REPORT_MANIFEST_SCOPE");
                    evidence=row.getBoolean("evidence_complete");checks=row.getBoolean("checks_complete");footer=true;
                } else throw fail("REPORT_MANIFEST_KIND");
            }
        }
        if(!footer||reportId==null||members==0)throw fail("REPORT_MANIFEST_INCOMPLETE");
        // Native readdir is bounded on API21. java.nio.file is unavailable until API26; File.listFiles allocates the entire directory.
        ReportNativeCP4.verifyArchiveDirectory(root,nextPart-1,control);
        return new Receipt(reportId,hex(full.digest()),scope,compressedBytes,rawBytes,nextPart-1,members,evidence,checks);
    }
    /** Service uses this native decoder after all Android snapshot connections have closed. */
    public static Decoder nativeDecoder(final long nativeBudget) {
        return (compressed,raw,bytes,control)->ReportNativeCP4.decompress(compressed,raw,bytes,nativeBudget,control);
    }
    /** Reconstruct every verified raw member into a standard ZIP using fixed size streaming buffers. */
    public static void writeZip(File archive,File destination,Decoder decoder,ReportNativeCP4.Control control)throws Exception {
        File partial=new File(destination.getPath()+".partial");
        try(FileOutputStream fd=new FileOutputStream(partial);
            java.util.zip.ZipOutputStream zip=new java.util.zip.ZipOutputStream(new BufferedOutputStream(ReportIoR31.protect(partial,fd,control),32768));
            LineReader lines=new LineReader(new FileInputStream(inside(archive,"manifest.jsonl")),8192)) {
            zip.setLevel(6);byte[] line;
            while((line=lines.next())!=null){checkpoint(control);JSONObject row=new JSONObject(new String(line,StandardCharsets.UTF_8));
                if(!"member".equals(row.getString("kind")))continue;
                String name=row.getString("name");requireName(name);long size=row.getLong("raw_bytes");
                zip.putNextEntry(new java.util.zip.ZipEntry(name));MessageDigest digest=sha();final long[] bytes={0};
                OutputStream sink=new OutputStream(){public void write(int b)throws IOException{byte[] a={(byte)b};write(a,0,1);}
                    public void write(byte[] b,int off,int len)throws IOException{checkpoint(control);if(len>size-bytes[0])throw fail("REPORT_ZIP_MEMBER_SIZE");zip.write(b,off,len);digest.update(b,off,len);bytes[0]+=len;}};
                try(InputStream input=new PartInput(archive,row.getInt("first_part"),row.getInt("part_count"),control)){decoder.decode(input,sink,size,control);if(input.read()!=-1)throw fail("REPORT_ZIP_TRAILING_BYTES");}
                if(bytes[0]!=size||!row.getString("raw_sha256").equals(hex(digest.digest())))throw fail("REPORT_ZIP_MEMBER_HASH");zip.closeEntry();
            }
            zip.putNextEntry(new java.util.zip.ZipEntry("ARCHIVE_MANIFEST.jsonl"));
            try(InputStream input=new FileInputStream(inside(archive,"manifest.jsonl"))){byte[] buffer=new byte[32768];int n;while((n=input.read(buffer))!=-1){checkpoint(control);zip.write(buffer,0,n);}}
            zip.closeEntry();zip.finish();zip.flush();fd.getFD().sync();
        }
        // Read every byte back, including each entry CRC, before publishing the new ZIP.
        try(java.util.zip.ZipInputStream input=new java.util.zip.ZipInputStream(new FileInputStream(partial))){byte[] buffer=new byte[32768];while(input.getNextEntry()!=null){int n;while((n=input.read(buffer))!=-1)checkpoint(control);input.closeEntry();}}
        if(destination.exists()&&!destination.delete())throw fail("REPORT_ZIP_REPLACE");
        if(!partial.renameTo(destination))throw fail("REPORT_ZIP_RENAME");
    }
    private static final class CountingDigest extends OutputStream {
        final MessageDigest digest=sha();final long limit;long count;
        CountingDigest(long limit){this.limit=limit;}
        public void write(int b)throws IOException{byte[] one={(byte)b};write(one,0,1);}
        public void write(byte[] b,int off,int len)throws IOException {
            if(b==null||off<0||len<0||off>b.length-len)throw new IndexOutOfBoundsException();
            if(len>limit-count)throw fail("REPORT_RAW_SIZE_EXCEEDED");digest.update(b,off,len);count+=len;
        }
    }
    private static final class PartInput extends InputStream {
        final File root;final int end;final ReportNativeCP4.Control control;int next;InputStream current;boolean closed;
        PartInput(File root,int first,int count,ReportNativeCP4.Control control){this.root=root;next=first;end=first+count;this.control=control;}
        public int read()throws IOException{byte[] one=new byte[1];return read(one,0,1)<0?-1:one[0]&255;}
        public int read(byte[] b,int off,int len)throws IOException {
            if(closed)throw fail("REPORT_PART_INPUT_CLOSED");if(b==null||off<0||len<0||off>b.length-len)throw new IndexOutOfBoundsException();
            if(len==0)return 0;checkpoint(control);
            for(;;){if(current==null){if(next==end)return -1;current=new FileInputStream(inside(root,String.format(Locale.ROOT,"P%06d.bin",next++)));}
                int n=current.read(b,off,len);if(n>=0)return n;current.close();current=null;}
        }
        public void close()throws IOException{closed=true;if(current!=null)current.close();}
    }
    public static final class LineReader implements Closeable {
        final InputStream in;final int maximum;private final byte[] buffer;private int at,end;private boolean eof;
        public LineReader(InputStream in,int maximum){if(in==null||maximum<1||maximum>131072)throw new IllegalArgumentException();this.in=in;this.maximum=maximum;buffer=new byte[8192];}
        public byte[] next()throws IOException {
            if(eof)return null;ByteArrayOutputStream row=new ByteArrayOutputStream(Math.min(512,maximum));
            for(;;){if(at==end){do{end=in.read(buffer);}while(end==0);at=0;if(end<0){eof=true;if(row.size()==0)return null;throw fail("REPORT_JSONL_UNTERMINATED");}}
                int b=buffer[at++]&255;if(row.size()>=maximum)throw fail("REPORT_JSONL_LINE_LIMIT");row.write(b);
                if(b==10)return row.toByteArray();}
        }
        public void close()throws IOException{in.close();}
    }
    private static String decodeUtf8(byte[] b,int off,int len)throws IOException {
        try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(java.nio.ByteBuffer.wrap(b,off,len)).toString();}catch(CharacterCodingException bad){throw fail("REPORT_JSONL_UTF8");}
    }
    public static File inside(File root,String child)throws IOException {
        if(child==null||child.isEmpty()||child.indexOf('\\')>=0||new File(child).isAbsolute())throw fail("REPORT_PRIVATE_PATH");
        File absolute=new File(root,child).getAbsoluteFile(),canonical=absolute.getCanonicalFile();
        if(!canonical.equals(absolute)||!canonical.getPath().startsWith(root.getCanonicalPath()+File.separator))throw fail("REPORT_PRIVATE_PATH");return canonical;
    }
    private static void checkpoint(ReportNativeCP4.Control control)throws IOException{if(Thread.currentThread().isInterrupted()||!control.shouldContinue())throw new InterruptedIOException("REPORT_CANCELLED");}
    private static void requireHash(String s)throws IOException{if(s==null||!s.matches("[0-9a-f]{64}"))throw fail("REPORT_HASH_FORMAT");}
    private static void requireName(String s)throws IOException{if(s==null||!s.matches("[A-Za-z0-9_.-]{1,120}"))throw fail("REPORT_MEMBER_NAME");}
    private static MessageDigest sha(){try{return MessageDigest.getInstance("SHA-256");}catch(NoSuchAlgorithmException impossible){throw new AssertionError(impossible);}}
    private static String hex(byte[] bytes){StringBuilder out=new StringBuilder(bytes.length*2);for(byte b:bytes){out.append("0123456789abcdef".charAt((b&255)>>>4));out.append("0123456789abcdef".charAt(b&15));}return out.toString();}
    private static IOException fail(String reason){return new IOException(reason);}
}
