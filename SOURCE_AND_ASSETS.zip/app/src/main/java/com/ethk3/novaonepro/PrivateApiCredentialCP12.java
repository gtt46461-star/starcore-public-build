package com.ethk3.novaonepro;

import android.content.Context;
import android.security.KeyPairGeneratorSpec;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.channels.FileLock;
import java.security.*;
import java.util.*;
import javax.crypto.Cipher;
import javax.security.auth.x500.X500Principal;

/** Device-private credential owner; no build, database, report or APK credential material. */
public final class PrivateApiCredentialCP12 {
    public interface Storage {
        String read() throws Exception;
        void write(String sealed) throws Exception;
        byte[] encrypt(byte[] plain) throws Exception;
        byte[] decrypt(byte[] sealed) throws Exception;
    }
    private static final String FORMAT="SC_API_CREDENTIAL_RSA_V1|";
    private final Storage storage;
    private volatile String key="",state="KEY_LOADING";
    private volatile String failureKind="";
    public PrivateApiCredentialCP12(Storage storage){this.storage=Objects.requireNonNull(storage);}
    public String get(){return key;}
    public String state(){return state;}
    public String failureReason(){return failureKind;}
    public synchronized void load(){
        byte[] plain=null;
        try{String sealed=storage.read();if(sealed.isEmpty()){key="";state="KEY_NOT_CONFIGURED";failureKind="PRIVATE_CREDENTIAL_ABSENT";return;}
            plain=unseal(sealed);String loaded=new String(plain,StandardCharsets.UTF_8);char[] chars=loaded.toCharArray();try{validate(chars);}finally{Arrays.fill(chars,'\0');}key=loaded;state="READY";failureKind="";
        }catch(Exception failure){key="";state="KEY_STORE_LOAD_FAILED";failureKind=safeFailure(failure);}finally{zero(plain);}
    }
    public synchronized void configure(char[] input)throws Exception {
        validate(input);byte[] plain=null,readback=null;String previous=storage.read(),previousKey=key,previousState=state;
        try{plain=new String(input).getBytes(StandardCharsets.UTF_8);String sealed=FORMAT+android.util.Base64.encodeToString(storage.encrypt(plain),android.util.Base64.NO_WRAP);
            storage.write(sealed);if(!sealed.equals(storage.read()))throw new IOException("KEY_STORE_READBACK_IDENTITY");
            readback=unseal(storage.read());if(!MessageDigest.isEqual(plain,readback))throw new IOException("KEY_STORE_READBACK_VALUE");
            key=new String(readback,StandardCharsets.UTF_8);state="READY";failureKind="";
        }catch(Exception failure){
            // Retain an existing credential only when the durable store still has its exact prior identity.
            try{if(previous.equals(storage.read())){key=previousKey;state=previousState;}else{key="";state="KEY_STORE_RECOVERY_REQUIRED";}}
            catch(Exception unreadable){key="";state="KEY_STORE_RECOVERY_REQUIRED";}failureKind=safeFailure(failure);
            throw new IOException("KEY_STORE_WRITE_FAILED",failure);
        }finally{zero(plain);zero(readback);}
    }
    private byte[] unseal(String sealed)throws Exception {
        if(sealed==null||sealed.length()>2048||!sealed.startsWith(FORMAT))throw new IOException("KEY_STORE_FORMAT");
        return storage.decrypt(android.util.Base64.decode(sealed.substring(FORMAT.length()),android.util.Base64.NO_WRAP));
    }
    private static void validate(char[] input)throws IOException {
        if(input==null||input.length<8||input.length>128)throw new IOException("KEY_INPUT_INVALID");
        for(char c:input)if(!(c>='a'&&c<='z')&&!(c>='A'&&c<='Z')&&!(c>='0'&&c<='9'))throw new IOException("KEY_INPUT_INVALID");
    }
    private static void zero(byte[] bytes){if(bytes!=null)Arrays.fill(bytes,(byte)0);}
    private static String safeFailure(Exception failure){String message=failure.getMessage();return message!=null&&(message.equals("KEY_STORE_FORMAT")||message.equals("KEY_KEYSTORE_MISSING")||message.equals("KEY_INPUT_INVALID")||message.startsWith("KEY_STORE_READBACK_"))?message:failure.getClass().getSimpleName();}

    /** RSA AndroidKeyStore is available at the supported API21 minimum; only user configuration creates a key pair. */
    static final class DeviceStorage implements Storage {
        private static final String ALIAS="STARCORE_DEVICE_API_CREDENTIAL_CP12_1";
        private static final Object FILE_LOCK=new Object();
        private interface FileWork<T>{T run()throws Exception;}
        private final Context app;
        DeviceStorage(Context context){app=context.getApplicationContext();}
        private File file(){return new File(app.getNoBackupFilesDir(),"starcore-api-credential-cp12.sealed");}
        private <T>T locked(FileWork<T> work)throws Exception{synchronized(FILE_LOCK){try(RandomAccessFile io=new RandomAccessFile(new File(app.getNoBackupFilesDir(),"starcore-api-credential-cp12.lock"),"rw");FileLock lock=io.getChannel().lock()){return work.run();}}}
        public String read()throws Exception{return locked(()->{File file=file();return file.exists()?ReportJobJournalCP12.readAtomic(file,2048):"";});}
        public void write(String sealed)throws Exception{locked(()->{ReportJobJournalCP12.writeAtomic(file(),sealed);return null;});}
        private KeyStore store()throws Exception{KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);return store;}
        public byte[] encrypt(byte[] plain)throws Exception {
            KeyStore store=store();if(!store.containsAlias(ALIAS)){
                KeyPairGenerator generator=KeyPairGenerator.getInstance("RSA","AndroidKeyStore");
                Calendar end=Calendar.getInstance();end.add(Calendar.YEAR,30);
                generator.initialize(new KeyPairGeneratorSpec.Builder(app).setAlias(ALIAS).setKeySize(2048).setSubject(new X500Principal("CN=STARCORE_PRIVATE_API_CP12")).setSerialNumber(BigInteger.ONE).setStartDate(new Date()).setEndDate(end.getTime()).build());generator.generateKeyPair();store=store();
            }
            Cipher cipher=Cipher.getInstance("RSA/ECB/PKCS1Padding");cipher.init(Cipher.ENCRYPT_MODE,store.getCertificate(ALIAS).getPublicKey());return cipher.doFinal(plain);
        }
        public byte[] decrypt(byte[] sealed)throws Exception {
            KeyStore store=store();if(!store.containsAlias(ALIAS))throw new IOException("KEY_KEYSTORE_MISSING");
            Cipher cipher=Cipher.getInstance("RSA/ECB/PKCS1Padding");cipher.init(Cipher.DECRYPT_MODE,store.getKey(ALIAS,null));return cipher.doFinal(sealed);
        }
    }
}
