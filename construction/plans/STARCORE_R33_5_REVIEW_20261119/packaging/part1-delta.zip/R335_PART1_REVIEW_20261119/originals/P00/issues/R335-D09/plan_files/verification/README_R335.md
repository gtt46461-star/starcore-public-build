# R33.5 当前验证入口与证据界限

当前一致性检查为 `check_r335_completion.py`，它检查P00+B01—B08九阶段、真实前后字节、完整后态与作者payload相同、跨批共享文件SHA链、关键钩子/受控差异保留、当前问题总账，以及原32工程组/96断言/288场景分母。`check_r334_completion.py`仍是原R33.4的历史检查，原文件保留；它的旧镜像相等约束不能约束已经合法修改的新后态，也不能为此重写旧审计原件。

## 当前全套宿主验证

先完成所有生产payload、after_full、问题总账、文档与类型编译证据；语义输入生成器由方案作者运行，施工方仅复核和应用。以下命令在解压后的方案根目录运行，Python3.12，JDK可用；宿主Java测试不会代替Android整包编译。当前任务还包括真实 RT10 owner 的115项宿主交叉断言，它必须读取本次完整源码前缀编译结果，禁止隐式使用旧 classes。先用固定033完整源码和真实API依赖建立独立工作目录：

```bash
export R335_CUSTODY_PREFIX_WORKDIR=/work/r335-current-prefix
export R335_ANDROID_JAR=/opt/android-sdk/platforms/android-36/android.jar
export R335_ANNOTATIONS_JAR=/work/dependencies/annotation-1.3.0.jar
python3 -B verification/run_stage_prefix_r335.py \
  --baseline-source /work/source-033 \
  --work-dir "$R335_CUSTODY_PREFIX_WORKDIR" \
  --android-jar "$R335_ANDROID_JAR" \
  --annotation-jar "$R335_ANNOTATIONS_JAR" --jdk-mode jdk17
```

该工作根目录必须新建或为空，包含最终 `prefix_candidate/` 与 `prefix_final/`。交叉任务将核对当前方案manifest、033及九阶段原生成器/编译回执、完整最终源码输入和依赖字节。缺少这些显式环境变量、阶段不完整或前缀对应旧方案时，测试拒绝执行；不能将依赖缺失改成跳过后算PASS。本次环境的JDK21类型夹具运行另标 `fixture21`，不等同于正式JDK17/Gradle构建。

```bash
python3 -B verification/check_r335_completion.py
python3 -B verification/seal_package_r335.py --before-host
python3 -B verification/run_host.py verification/HOST_RUNS.json
python3 -B verification/seal_package_r335.py --after-host
python3 -B verification/verify_package.py
```

每套测试先从同一已封输入快照普通复制一个独立工作目录，然后再并行运行。禁止可写硬链接；旧B05重建类测试即使会生成/替换文件，也只影响自己的副本。原始stdout/stderr存于 `verification/host_logs_R335/`，收据记录每套输入集摘要和执行前seal；最终检查同时复核命令、scope和完整日志SHA，旧日志不能代替本次执行。失败保持失败，不能为了得到全绿把失败套件删去。

`HOST_RUNS.json`也会进入最终交付seal，因此不能让它反过来包含自己的最终seal摘要。这里采用明确的两次封存：执行前seal锁定实际输入；运行收据逐文件记录执行输入哈希；最终seal同时封住输入和收据。最终检查重新比较全部执行输入的字节与成员集，生产文件/脚本/工单/文档有任何未重测变化都会拒绝复用旧成功。

只有以下证据输出不参与“被测输入”自身哈希：最终SHA清单、HOST_RUNS/CURRENT_HOST收据、R335最终交付/总验证/预封存摘要，以及 `verification/host_logs_R335/`。它们仍由最终包seal保护。`run_host.py`中的固定白名单是权威定义；不能临时扩大白名单藏未测代码。

任务路由中标注 `HISTORICAL_FIXTURE_BOUNDARY_ONLY` 的套件只检查旧边界/反例；`HISTORICAL_REGENERATION_FIXTURE_ONLY` 只验证旧11文件生成器自身，不能把它重建后的代码当成R33.5完整后态；两者均不能当成当前Android生产链运行证据。当前新实现的Java数值回归和全源类型编译另留原始命令与结果。宿主测试、源码类型核验、Gradle/D8/NDK整包编译、模拟器、V2353A真机和自然未来质量分别记状态。

## 当前应保留的实测反例

- 两个并行测试都改同名生产文件：各自看到自己的修改，原包不变；修改执行后源代码则旧HOST_RUNS无法复用。
- 已有P00递增版本提交后进入B01：新版本完整继承；重复把P00初始身份强覆回去会DIVERGED。
- B01/B04先修改共享源，B02/B05必须保留早批变化；旧patch中已被完整后态替代的路径明确登记 `REPLACED_BY_FULL_AFTER`，无完整后态的路径仍精确apply。
- 机会日历结构合法但截止与数据库相差6秒：新主链验证必须拒绝，不能只打印差值。
- Git源码bundle在空仓库恢复：有外部对象前置、浅历史、非确切HEAD或重复输出都不能称为独立源码交付。

这些反例防止工具给出错误通过；它们本身不会证明自然高胜率，也不会替应用创建、升级或消费任何资格证书。新增Java/Android平台API另见 `minsdk_r335/README.md`：逐阶段差异符号解析与固定D8/L8的最小真实DEX验证均有原始证据，仍与全应用APK及设备验收分开。
