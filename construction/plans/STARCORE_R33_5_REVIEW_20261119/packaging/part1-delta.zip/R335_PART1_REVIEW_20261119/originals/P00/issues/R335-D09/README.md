# R335-D09 · 并行宿主测试共享可写工作树可互相覆盖或回退新代码

**责任阶段：P00｜状态：IMPLEMENTED_CANDIDATE**

原问题/工单：C13, RG-01。本问题中的完整文件用于独立审阅；正式安装只按总manifest和批次顺序执行一次。

## 原因与具体处理

每套任务独立普通copy；先校验执行前seal，逐任务绑定输入集hash，保存完整stdout/stderr；最终封包验证实际输入字节未变化，执行前seal与最终交付seal分开避免收据自引用。 最终复核每套command/scope及完整原始stdout/stderr哈希；旧11文件重建套件标记为HISTORICAL_REGENERATION_FIXTURE_ONLY。

### 原证据

旧实现只复制一次work，却用3线程执行会重生成payload的测试与读取payload的测试；存在顺序竞争，无法证明每套真实输入是同一新代码。

## 逐文件代码与操作

| 文件 | 操作/安装批次 | 完整代码 | 后态SHA256 |
|---|---|---|---|
| `verification/run_host.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/run_host.py) | `a86be7c9176857e50aeb55ba2e8e67571c725b5207f9e152329b3b2315524959` |
| `verification/test_host_isolation_r335.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/test_host_isolation_r335.py) | `d6bccd8f753de5fd54225a9813663ee6c30b167523ae2b631aa4e4e9e9f903c1` |
| `verification/seal_package_r335.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/seal_package_r335.py) | `f827d61ddaad6df72fb780c932c78930a2697a50e985757a682aad083edb472f` |
| `verification/verify_package.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/verify_package.py) | `a75b4259b2c237204c0659c6916d26d66eea39bf2d0b9c2fef8f1f0ef7c0eebf` |
| `verification/README_R335.md` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/README_R335.md) | `01182c1bb5091f2561deae9336f45cd2fef91496d200b46086ea6b614a1f641e` |

## 受影响方法与共享文件

逐文件字段/方法的前后结构与SHA统一见 [`control/FILE_REVIEW_R335.json`](../../../control/FILE_REVIEW_R335.json)。同一文件涉及多问题时，本卡放的是本批完整共同后态，不能只应用某个片段后覆盖其他问题修复。

## 自检及施工退出

- 2项真实并行文件改写/原包保全/输入漂移、错命令与旧日志拒绝回归通过。最终统一全套待所有源码冻结后运行。

所有当前执行结果以包内 CURRENT_VALIDATION_R335/HOST_RUNS 和本专项原receipt为准；测试源文件存在不等于已执行。施工时复核相同输入/代次/角色，分别运行正常、重复、错误输入、取消/重启及提交返回丢失场景。每项证据绑定源commit、方案摘要、caseId和原始文件，失败记录保留。

## 恢复与边界

- Android APK/设备/自然质量未由宿主验证代替。

源码在隔离工作树中应用；前态SHA不同则保留并做三方移植。既有业务事实、父代、失败和原件不可由回退删除；未获原完整恢复证明的数据不自动清理。
