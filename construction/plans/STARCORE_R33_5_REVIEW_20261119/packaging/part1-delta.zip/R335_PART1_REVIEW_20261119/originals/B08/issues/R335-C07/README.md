# R335-C07 · 固定32组96断言288场景的同构建终审与反作弊

**责任阶段：B08｜状态：EXISTING_REPAIR_INCLUDED_CURRENT_VALIDATION_SEPARATE**

原问题/工单：RG-01。本问题中的完整文件用于独立审阅；正式安装只按总manifest和批次顺序执行一次。

## 原因与具体处理

保留固定原句/摘要/分母，V2逐case约束正例负例/trace环境、原件链接与当前APK/源码/方案身份；历史源、虚拟导出ZIP和代表例不能替代全组。

## 逐文件代码与操作

| 文件 | 操作/安装批次 | 完整代码 | 后态SHA256 |
|---|---|---|---|
| `verification/score_final.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/score_final.py) | `58aec36ecab0565e73b32bf4a0137600a5d4e96dad0dc2e7e906803da912aef3` |
| `verification/scenario_coverage.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/scenario_coverage.py) | `b2a98e5c7b25828dde67ea522efcf8392135b3bedb4bf32d2e095af1cd72a0f6` |
| `verification/test_final_envelopes.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/test_final_envelopes.py) | `1196a9760ca38bb74acda821f27b372565450b6f70390a1a4fe68bf1abe27749` |
| `verification/test_scenario_coverage.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/test_scenario_coverage.py) | `f7bf70f1027415d14c8e00c3299c05ed57cecc1d732403c2586d0280d3cc1d32` |
| `verification/check_delivery_structure_r335.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/check_delivery_structure_r335.py) | `6cc3934edde3128ea95f9c7c45bb554c394a0eae08c60a8d7f2d75390b695a7d` |
| `verification/run_stage_prefix_r335.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/run_stage_prefix_r335.py) | `b0664219d5a111e21c46affa6ba297e80fcc3d0570e6c6a0abc305e348eef823` |
| `verification/typecheck_full_source_r335.py` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/verification/typecheck_full_source_r335.py) | `7b63ad06e576b654fcd49ece29b2dbab74f08578ea42633e9a67f2a681f48584` |
| `control/required_scenarios_R334.json` | PACKAGE_ONLY / 保留或包内工具 | [打开完整文件](plan_files/control/required_scenarios_R334.json) | `018e2cb8541de672f7c1e99e97a39dab8db699ce4bf0577d637b4c8b10c35535` |

## 受影响方法与共享文件

逐文件字段/方法的前后结构与SHA统一见 [`control/FILE_REVIEW_R335.json`](../../../control/FILE_REVIEW_R335.json)。同一文件涉及多问题时，本卡放的是本批完整共同后态，不能只应用某个片段后覆盖其他问题修复。

## 自检及施工退出

- verification/test_final_envelopes.py
- verification/test_scenario_coverage.py
- B08/code/test_delivery_guards.py

所有当前执行结果以包内 CURRENT_VALIDATION_R335/HOST_RUNS 和本专项原receipt为准；测试源文件存在不等于已执行。施工时复核相同输入/代次/角色，分别运行正常、重复、错误输入、取消/重启及提交返回丢失场景。每项证据绑定源commit、方案摘要、caseId和原始文件，失败记录保留。

## 恢复与边界

- 当前未产生同签APK/目标机72小时/自然窗口，整体验收仍0/32；工具不能证明人为提交的原始日志绝不造假。

源码在隔离工作树中应用；前态SHA不同则保留并做三方移植。既有业务事实、父代、失败和原件不可由回退删除；未获原完整恢复证明的数据不自动清理。
