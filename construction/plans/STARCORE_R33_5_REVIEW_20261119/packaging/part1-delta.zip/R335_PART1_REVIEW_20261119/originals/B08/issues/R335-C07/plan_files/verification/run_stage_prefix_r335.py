"""Rebuild each ordered candidate in a new work directory from a verified full baseline.

The candidate is a plain source materialization, not production Git history.
Original semantic/source generators run for each prefix before type checks.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-source', required=True, help='Unmodified complete source at the bound 033 baseline')
    parser.add_argument('--work-dir', required=True, help='New or empty scratch directory; never the source or plan directory')
    parser.add_argument('--android-jar', required=True)
    parser.add_argument('--annotation-jar', required=True)
    parser.add_argument('--jdk-mode', choices=['jdk17','fixture21'], default='jdk17')
    parser.add_argument('--java', default='java')
    parser.add_argument('--plan-root', default=str(Path(__file__).resolve().parents[1]))
    return parser.parse_args()

ARGS = arguments()
PLAN = Path(ARGS.plan_root).resolve()
BASE = Path(ARGS.baseline_source).resolve()
WORK = Path(ARGS.work_dir).resolve()
if WORK == BASE or WORK.is_relative_to(BASE) or BASE.is_relative_to(WORK):
    raise ValueError('Scratch work directory must not overlap baseline source')
if WORK == PLAN or WORK.is_relative_to(PLAN) or PLAN.is_relative_to(WORK):
    raise ValueError('Scratch work directory must not overlap the construction package')
if WORK.exists() and (not WORK.is_dir() or any(WORK.iterdir())):
    raise ValueError('Refusing to replace a non-empty work directory; select a new empty path')
for required in [PLAN/'control/APPLY_MANIFEST_R335.json', BASE/'release/release_manifest.json']:
    if not required.is_file():
        raise ValueError('Required input missing: ' + str(required))
JAVA = shutil.which(ARGS.java)
if not JAVA:
    raise ValueError('Java executable not found: ' + ARGS.java)
CANDIDATE = WORK / 'prefix_candidate'
OUT = WORK / 'prefix_final'
ANDROID = Path(ARGS.android_jar).resolve()
ANNOTATION = Path(ARGS.annotation_jar).resolve()
for required in [ANDROID, ANNOTATION]:
    if not required.is_file():
        raise ValueError('Required type dependency missing: ' + str(required))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run_stage(stage, files):
    for row in files:
        source = PLAN / row['payload']
        if sha(source) != row['afterSha256']:
            raise ValueError('INPUT_SHA_CHANGED:' + row['path'])
        target = CANDIDATE / row['path']
        before = sha(target) if target.is_file() else 'NEW'
        if before != row['beforeSha256']:
            raise ValueError('PREFIX_BEFORE_MISMATCH:' + stage + ':' + row['path'])
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    folder = OUT / stage
    folder.mkdir(parents=True, exist_ok=True)
    provenance_args = ['--root', str(CANDIDATE), '--toolchain-file', 'HOST_FIXTURE_JAVA=' + str(Path(JAVA).resolve()),
                       '--toolchain-file', 'ANDROID_API36_TYPES=' + str(ANDROID),
                       '--toolchain-file', 'ANDROIDX_ANNOTATION_TYPES=' + str(ANNOTATION)]
    commands = [
        [sys.executable, '-B', str(CANDIDATE/'scripts/verify_catalog_assets_cp12.py'), '--check'],
        [sys.executable, '-B', str(CANDIDATE/'scripts/generate_strategy_su2_schema.py'), '--check'],
        [sys.executable, '-B', str(CANDIDATE/'scripts/r967_semantic_identity.py')],
        [sys.executable, '-B', str(CANDIDATE/'scripts/r967_semantic_identity.py'), '--check'],
        [sys.executable, '-B', str(CANDIDATE/'scripts/r967_semantic_identity.py'), '--self-test'],
        [sys.executable, '-B', str(CANDIDATE/'scripts/r815_generate_provenance.py'), *provenance_args],
        [sys.executable, '-B', str(CANDIDATE/'scripts/r815_generate_provenance.py'), '--check', *provenance_args],
    ]
    rows = []
    for index, command in enumerate(commands, 1):
        result = subprocess.run(command, cwd=CANDIDATE, capture_output=True, text=True)
        log = folder / ('generator-%02d.log' % index)
        log.write_text(result.stdout + result.stderr)
        rows.append({'command': command, 'exitCode': result.returncode, 'log': log.name, 'logSha256': sha(log)})
        print(stage, 'generator', index, result.returncode, result.stdout.strip()[-500:], flush=True)
        if result.returncode:
            print(result.stderr, flush=True)
            (folder/'GENERATORS.json').write_text(json.dumps({'scope':'ORIGINAL_GENERATORS_HOST_TOOLCHAIN_ONLY','runs':rows}, ensure_ascii=False, indent=2)+'\n')
            raise SystemExit(result.returncode)
    generated = {}
    for name in ['app/build/generated/source/r967/com/ethk3/novaonepro/ResearchSemanticsGeneratedR967.java',
                 'app/build/generated/source/r815/com/ethk3/novaonepro/BuildSourceIdentityCP12.java',
                 'app/build/generated/r967/semantic_manifest.json',
                 'app/build/generated/r815/source-manifest.json']:
        source = CANDIDATE/name
        destination = folder/'generated'/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        generated[name] = sha(source)
    (folder/'GENERATORS.json').write_text(json.dumps({'scope':'ORIGINAL_GENERATORS_HOST_TOOLCHAIN_ONLY',
        'notRun':'Gradle/DEX/native/signing/device. Declared toolchain is the actual host fixture, not Android build toolchain.',
        'runs':rows,'generated':generated}, ensure_ascii=False, indent=2)+'\n')
    command = [sys.executable,'-B',str(PLAN/'verification/typecheck_full_source_r335.py'), '--repo',str(CANDIDATE),
               '--android-jar',str(ANDROID),'--annotation-jar',str(ANNOTATION),'--jdk-mode',ARGS.jdk_mode,'--java',JAVA,'--out',str(folder)]
    result = subprocess.run(command, capture_output=True, text=True)
    print(stage, 'typecheck', result.returncode, result.stdout.strip(), flush=True)
    if result.returncode:
        print(result.stderr, flush=True)
        raise SystemExit(result.returncode)


if __name__ == '__main__':
    # A new empty work directory is required; no source or old result is deleted.
    WORK.mkdir(parents=True, exist_ok=True)
    def ignore(directory, names):
        omitted = [x for x in names if x in ('__pycache__', '.git', '.gradle')]
        if Path(directory) == BASE/'app' and 'build' in names:
            omitted.append('build')
        return omitted
    shutil.copytree(BASE, CANDIDATE, ignore=ignore)
    OUT.mkdir(parents=True)
    manifest = json.loads((PLAN/'control/APPLY_MANIFEST_R335.json').read_text())
    (OUT/'PREFIX_INPUT_MANIFEST_R335.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    run_stage('BASELINE033', [])
    for batch in manifest['batches']:
        run_stage(batch['id'], batch['files'])
    print('ALL_PREFIX_GENERATORS_AND_TYPES_PASS', flush=True)
