# B08 · 同APK整合、升级、签名与源码交付

本批 4 个施工工单；0 个安装文件变化。原工程验收分母不因工单数增加而变化。

前置阶段：B07的实际已提交成果。完整后态位于after_full，已有前态位于before_full。零生产差异的验证阶段也必须做其原件验收，不凭空修改稳定门。

| 问题 | 代码文件项数 | 处理 | 当前验证状态 |
|---|---:|---|---|
| [R335-C07 · 固定32组96断言288场景的同构建终审与反作弊](issues/R335-C07/README.md) | 8 | 保留固定原句/摘要/分母，V2逐case约束正例负例/trace环境、原件链接与当前APK/源码/方案身份；历史源、虚拟导出ZIP和代表例不能替代全组。 | EXISTING_REPAIR_INCLUDED_CURRENT_VALIDATION_SEPARATE |
| [R335-D05 · 源码ZIP不含Git历史，不能独立复原已有构建基线门](issues/R335-D05/README.md) | 2 | 交付强制增加只含HEAD可达历史的Git bundle，在空仓库校验无外部前置对象、取回HEAD和tree以及033祖先；拒浅历史及目标覆盖。 | IMPLEMENTED_CANDIDATE |
| [R335-D06 · 独立主链验收漏核机会日历与冻结截止一致](issues/R335-D06/README.md) | 2 | 强制预注册deadlineAt与源期计算deadline、request和freeze deadline完全一致；保留所有错误机会在分母。 | IMPLEMENTED_CANDIDATE |
| [R335-D07 · 独立APK验证器“更高版本”比较未覆盖033基线](issues/R335-D07/README.md) | 2 | validate_upgrade_identity强制安装版正整数、候选严格大于max(现场安装版,033)，同时匹配包名/候选版本名。 | IMPLEMENTED_CANDIDATE |

## 本批安装文件

| 仓库路径 | 操作 | 完整后态 | 前SHA256 | 后SHA256 |
|---|---|---|---|---|

## 完成与交接

按根目录03_逐批安装验证回退.md执行：受控安装→针对本批实际问题复现/修复→当前完整源码检查→版本四文件事务→提交→原签真实Gradle/本批设备正反例→完整回执。当前未执行的Android/自然条件按本卡限制列明。进入下一批必须使用本批真实HEAD，不能把未提交的新代码丢在前一工作树。
