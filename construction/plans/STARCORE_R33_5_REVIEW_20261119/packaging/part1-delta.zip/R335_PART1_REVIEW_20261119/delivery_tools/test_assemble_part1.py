#!/usr/bin/env python3
"""Small, local failure fixtures for assemble_part1.py; no network or real archive."""

from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


SCRIPT = Path(__file__).with_name("assemble_part1.py")
SPEC = importlib.util.spec_from_file_location("assemble_part1", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def sha(data):
    return hashlib.sha256(data).hexdigest()


class ArchiveAssemblyTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="r335-chunk-fixture-")
        self.root = Path(self.temp.name)
        self.inputs = self.root / "bundle"
        self.inputs.mkdir()
        (self.inputs / "chunks").mkdir()
        self.payload = bytes(range(256)) * 101 + b"\x00R335-fixture-end\xff"
        self.output = self.root / "restored.zip"
        self.manifest_path = self.inputs / "PART1_CHUNKS.json"
        chunks = []
        for index, offset in enumerate(range(0, len(self.payload), 8192)):
            data = self.payload[offset:offset + 8192]
            name = f"chunks/part1.{index:03d}"
            (self.inputs / name).write_bytes(data)
            chunks.append({"path": name, "size_bytes": len(data), "sha256": sha(data)})
        self.manifest = {
            "schema": MODULE.SCHEMA,
            "archive": {"name": "original.zip", "size_bytes": len(self.payload),
                        "sha256": sha(self.payload)},
            "chunks": chunks,
        }
        self.save()

    def tearDown(self):
        self.temp.cleanup()

    def save(self):
        self.manifest_path.write_text(json.dumps(self.manifest), encoding="utf-8")

    def assemble(self):
        return MODULE.assemble(self.manifest_path, self.output)

    def assert_clean(self):
        self.assertEqual(list(self.root.glob(MODULE.TEMP_PREFIX + "*")), [])

    def assert_refused(self, expected_error=None):
        old = self.output.read_bytes() if self.output.is_file() else None
        with self.assertRaises((MODULE.AssemblyError, OSError)) as raised:
            self.assemble()
        if expected_error:
            self.assertIn(expected_error, str(raised.exception))
        if old is None:
            self.assertFalse(self.output.exists())
        else:
            self.assertEqual(self.output.read_bytes(), old)
        self.assert_clean()

    def test_normal_streamed_reconstruction(self):
        result = self.assemble()
        self.assertEqual(self.output.read_bytes(), self.payload)
        self.assertEqual(result["status"], "ASSEMBLED_VERIFIED")
        self.assertEqual(result["chunks_verified"], 4)
        self.assertEqual(result["sha256"], sha(self.payload))
        self.assert_clean()

    def test_cli_default_manifest_beside_script(self):
        copied_script = self.inputs / SCRIPT.name
        shutil.copyfile(SCRIPT, copied_script)
        result = subprocess.run([sys.executable, "-B", str(copied_script),
                                 "--output", str(self.output)],
                                cwd=self.root, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["status"], "ASSEMBLED_VERIFIED")
        self.assertEqual(self.output.read_bytes(), self.payload)

    def test_missing_chunk_leaves_no_partial_output(self):
        (self.inputs / self.manifest["chunks"][2]["path"]).unlink()
        self.assert_refused("PATH_MISSING")

    def test_changed_byte_with_same_size_is_rejected(self):
        path = self.inputs / self.manifest["chunks"][1]["path"]
        data = bytearray(path.read_bytes())
        data[50] ^= 1
        path.write_bytes(data)
        self.assert_refused("CHUNK_SHA256_MISMATCH")

    def test_reordered_valid_chunks_fail_whole_archive_hash(self):
        # The first three chunk bytes happen to repeat; swap the short final
        # chunk with the first to test order rather than only list metadata.
        chunks = self.manifest["chunks"]
        chunks[0], chunks[-1] = chunks[-1], chunks[0]
        self.save()
        self.assert_refused("ARCHIVE_SHA256_MISMATCH")

    def test_duplicate_chunk_path_is_rejected(self):
        self.manifest["chunks"][1] = dict(self.manifest["chunks"][0])
        self.save()
        self.assert_refused("DUPLICATE_CHUNK_PATH")

    def test_parent_traversal_and_absolute_paths_are_rejected(self):
        original = self.manifest["chunks"][0]["path"]
        for bad in ("../outside.part", str(self.root / "absolute.part"),
                    "chunks/../part", "C:/outside.part", "chunks\\part"):
            with self.subTest(path=bad):
                self.manifest["chunks"][0]["path"] = bad
                self.save()
                self.assert_refused()
        self.manifest["chunks"][0]["path"] = original

    def test_symlink_chunk_and_parent_are_rejected(self):
        chunk = self.inputs / self.manifest["chunks"][0]["path"]
        real = self.inputs / "actual.part"
        chunk.rename(real)
        chunk.symlink_to(real)
        self.assert_refused("SYMLINK_REFUSED")
        chunk.unlink()
        real.rename(chunk)
        directory = self.inputs / "chunks"
        real_directory = self.inputs / "actual-chunks"
        directory.rename(real_directory)
        directory.symlink_to(real_directory, target_is_directory=True)
        self.assert_refused("SYMLINK_REFUSED")

    def test_symlink_escape_is_rejected(self):
        outside = self.root / "outside.part"
        outside.write_bytes((self.inputs / self.manifest["chunks"][0]["path"]).read_bytes())
        chunk = self.inputs / self.manifest["chunks"][0]["path"]
        chunk.unlink()
        chunk.symlink_to(outside)
        self.assert_refused("CHUNK_PATH_OUTSIDE_MANIFEST")

    def test_chunk_length_and_total_hash_are_checked(self):
        chunk = self.inputs / self.manifest["chunks"][2]["path"]
        original = chunk.read_bytes()
        chunk.write_bytes(original[:-1])
        self.assert_refused("CHUNK_SIZE_MISMATCH")
        chunk.write_bytes(original)
        self.manifest["archive"]["sha256"] = "0" * 64
        self.save()
        self.assert_refused("ARCHIVE_SHA256_MISMATCH")

    def test_existing_different_file_is_preserved(self):
        self.output.write_bytes(b"user-owned-existing-file")
        self.assert_refused("EXISTING_OUTPUT_DIFFERS")

    def test_existing_identical_is_idempotent_and_still_checks_chunks(self):
        self.output.write_bytes(self.payload)
        before = self.output.stat()
        result = self.assemble()
        after = self.output.stat()
        self.assertEqual(result["status"], "ALREADY_PRESENT_IDENTICAL")
        self.assertEqual((before.st_ino, before.st_mtime_ns), (after.st_ino, after.st_mtime_ns))
        self.assert_clean()
        path = self.inputs / self.manifest["chunks"][1]["path"]
        path.write_bytes(b"x" * path.stat().st_size)
        self.assert_refused("CHUNK_SHA256_MISMATCH")

    def test_existing_output_symlink_is_refused(self):
        actual = self.root / "existing-real.zip"
        actual.write_bytes(self.payload)
        self.output.symlink_to(actual)
        self.assert_refused("SYMLINK_REFUSED")
        self.assertTrue(self.output.is_symlink())
        self.assertEqual(actual.read_bytes(), self.payload)

    def test_concurrent_different_output_is_never_overwritten(self):
        real_link = os.link

        def race(source, target, **kwargs):
            self.output.write_bytes(b"concurrent-user-output")
            return real_link(source, target, **kwargs)

        with mock.patch.object(MODULE.os, "link", side_effect=race):
            with self.assertRaisesRegex(MODULE.AssemblyError, "EXISTING_OUTPUT_DIFFERS"):
                self.assemble()
        self.assertEqual(self.output.read_bytes(), b"concurrent-user-output")
        self.assert_clean()

    def test_duplicate_manifest_key_is_rejected(self):
        self.manifest_path.write_text('{"schema":"first","schema":"second"}', encoding="utf-8")
        self.assert_refused("DUPLICATE_MANIFEST_KEY")


if __name__ == "__main__":
    unittest.main(verbosity=2)
