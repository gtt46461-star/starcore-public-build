#!/usr/bin/env python3
"""Verify and assemble local archive chunks; never download, extract, or overwrite.

Usage:
  python3 assemble_part1.py --output /existing/directory/part1.zip
  python3 assemble_part1.py --manifest PART1_CHUNKS.json --output part1.zip

The default manifest is PART1_CHUNKS.json beside this script. Chunk paths are
relative to the manifest directory. The output parent must already exist.
An existing output is accepted only if its size and SHA-256 are identical;
the chunks are still verified. Installation uses a same-directory hard link
for atomic, no-overwrite publication, then removes the temporary name.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import stat
import sys
import tempfile


SCHEMA = "STARCORE_R335_PART1_CHUNKS_V1"
BLOCK_BYTES = 1024 * 1024
MAX_MANIFEST_BYTES = 1024 * 1024
TEMP_PREFIX = ".starcore-part1-"


class AssemblyError(ValueError):
    """Invalid input or an output that must not be replaced."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssemblyError(message)


def unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        require(key not in result, "DUPLICATE_MANIFEST_KEY: " + key)
        result[key] = value
    return result


def validated_size(value: object, field: str) -> int:
    require(type(value) is int and value >= 0, "INVALID_SIZE: " + field)
    return value


def validated_hash(value: object, field: str) -> str:
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
            "INVALID_SHA256: " + field)
    return value


def relative_path(value: object) -> PurePosixPath:
    require(isinstance(value, str) and bool(value) and "\0" not in value,
            "INVALID_CHUNK_PATH")
    require("\\" not in value and not PureWindowsPath(value).drive,
            "NON_PORTABLE_CHUNK_PATH: " + value)
    path = PurePosixPath(value)
    require(not path.is_absolute() and ".." not in path.parts
            and value not in (".", "..") and path.as_posix() == value,
            "CHUNK_PATH_ESCAPE_OR_NONCANONICAL: " + value)
    return path


def check_ancestors(path: Path, *, allow_missing_leaf: bool = False) -> None:
    """Reject symbolic links and non-directory parent components."""
    path = path.absolute()
    for candidate in [*reversed(path.parents), path]:
        try:
            metadata = candidate.lstat()
        except FileNotFoundError:
            if candidate == path and allow_missing_leaf:
                return
            raise AssemblyError("PATH_MISSING: " + str(candidate)) from None
        require(not stat.S_ISLNK(metadata.st_mode), "SYMLINK_REFUSED: " + str(candidate))
        if candidate != path:
            require(stat.S_ISDIR(metadata.st_mode), "PARENT_NOT_DIRECTORY: " + str(candidate))


def open_regular(path: Path):
    check_ancestors(path)
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), "REGULAR_FILE_REQUIRED: " + str(path))
        return os.fdopen(fd, "rb")
    except BaseException:
        os.close(fd)
        raise


def file_identity(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    count = 0
    with open_regular(path) as stream:
        while block := stream.read(BLOCK_BYTES):
            count += len(block)
            digest.update(block)
    return count, digest.hexdigest()


def read_manifest(manifest_path: Path) -> tuple[Path, dict, list[dict]]:
    manifest_path = manifest_path.absolute()
    with open_regular(manifest_path) as stream:
        raw = stream.read(MAX_MANIFEST_BYTES + 1)
    require(len(raw) <= MAX_MANIFEST_BYTES, "MANIFEST_TOO_LARGE")
    manifest = json.loads(raw, object_pairs_hook=unique_object)
    require(isinstance(manifest, dict) and manifest.get("schema") == SCHEMA,
            "MANIFEST_SCHEMA_MISMATCH")
    archive = manifest.get("archive")
    require(isinstance(archive, dict), "ARCHIVE_DESCRIPTOR_REQUIRED")
    archive_name = relative_path(archive.get("name"))
    require(len(archive_name.parts) == 1, "ARCHIVE_NAME_MUST_BE_BASENAME")
    archive_size = validated_size(archive.get("size_bytes"), "archive.size_bytes")
    validated_hash(archive.get("sha256"), "archive.sha256")
    chunks = manifest.get("chunks")
    require(isinstance(chunks, list) and bool(chunks), "NONEMPTY_CHUNKS_REQUIRED")
    base = manifest_path.parent.resolve(strict=True)
    seen = set()
    total = 0
    for index, chunk in enumerate(chunks):
        require(isinstance(chunk, dict), "CHUNK_DESCRIPTOR_REQUIRED")
        relative = relative_path(chunk.get("path"))
        require(relative.as_posix() not in seen, "DUPLICATE_CHUNK_PATH: " + str(relative))
        seen.add(relative.as_posix())
        total += validated_size(chunk.get("size_bytes"), f"chunks[{index}].size_bytes")
        validated_hash(chunk.get("sha256"), f"chunks[{index}].sha256")
        candidate = base.joinpath(*relative.parts)
        require(candidate.resolve(strict=False).is_relative_to(base),
                "CHUNK_PATH_OUTSIDE_MANIFEST: " + str(relative))
    require(total == archive_size, "CHUNK_SIZES_DO_NOT_SUM_TO_ARCHIVE")
    return base, archive, chunks


def existing_matches(output: Path, expected: tuple[int, str]) -> bool:
    """Return false only for an absent leaf; never follow an existing symlink."""
    try:
        output.lstat()
    except FileNotFoundError:
        return False
    require(file_identity(output) == expected, "EXISTING_OUTPUT_DIFFERS: " + str(output))
    return True


def assemble(manifest_path: Path, output: Path) -> dict:
    base, archive, chunks = read_manifest(Path(manifest_path))
    output = Path(output).absolute()
    check_ancestors(output, allow_missing_leaf=True)
    require(output.parent.is_dir(), "OUTPUT_PARENT_NOT_DIRECTORY")
    expected = (archive["size_bytes"], archive["sha256"])
    # Refuse an existing different file before allocating any temporary output.
    existing_matches(output, expected)
    fd, temporary_name = tempfile.mkstemp(prefix=TEMP_PREFIX, suffix=".tmp", dir=output.parent)
    temporary = Path(temporary_name)
    try:
        total_hash = hashlib.sha256()
        total_size = 0
        with os.fdopen(fd, "wb") as destination:
            for chunk in chunks:
                relative = relative_path(chunk["path"])
                source = base.joinpath(*relative.parts)
                require(source.resolve(strict=False).is_relative_to(base),
                        "CHUNK_PATH_OUTSIDE_MANIFEST: " + str(relative))
                part_hash = hashlib.sha256()
                part_size = 0
                with open_regular(source) as stream:
                    require(os.fstat(stream.fileno()).st_size == chunk["size_bytes"],
                            "CHUNK_SIZE_MISMATCH: " + str(relative))
                    while block := stream.read(BLOCK_BYTES):
                        part_size += len(block)
                        require(part_size <= chunk["size_bytes"],
                                "CHUNK_GREW_DURING_READ: " + str(relative))
                        part_hash.update(block)
                        total_hash.update(block)
                        total_size += len(block)
                        destination.write(block)
                require(part_size == chunk["size_bytes"], "CHUNK_SIZE_MISMATCH: " + str(relative))
                require(part_hash.hexdigest() == chunk["sha256"],
                        "CHUNK_SHA256_MISMATCH: " + str(relative))
            require(total_size == expected[0], "ARCHIVE_SIZE_MISMATCH")
            require(total_hash.hexdigest() == expected[1], "ARCHIVE_SHA256_MISMATCH")
            destination.flush()
            os.fsync(destination.fileno())
        check_ancestors(output, allow_missing_leaf=True)
        if existing_matches(output, expected):
            status = "ALREADY_PRESENT_IDENTICAL"
        else:
            try:
                # Atomic create-if-absent; unlike os.replace this cannot overwrite
                # an output created by another process after the check above.
                os.link(temporary, output, follow_symlinks=False)
                status = "ASSEMBLED_VERIFIED"
            except FileExistsError:
                require(existing_matches(output, expected), "OUTPUT_RACE_RETRY_REQUIRED")
                status = "ALREADY_PRESENT_IDENTICAL"
        return {"status": status, "output": str(output), "size_bytes": total_size,
                "sha256": total_hash.hexdigest(), "chunks_verified": len(chunks)}
    finally:
        temporary.unlink(missing_ok=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path,
                        default=Path(__file__).resolve().with_name("PART1_CHUNKS.json"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = assemble(args.manifest, args.output)
    except (AssemblyError, OSError, TypeError, json.JSONDecodeError) as error:
        print("ASSEMBLY_REFUSED: " + str(error), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
