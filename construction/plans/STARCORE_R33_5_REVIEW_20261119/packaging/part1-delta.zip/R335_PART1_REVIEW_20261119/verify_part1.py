#!/usr/bin/env python3
"""Read-only integrity check for the reviewed first R33.5 delivery part.

This checks the first part and its repair receipt only.  It neither runs the
application nor promotes the archived HOST_RUNS receipt to a current PASS.
The delivered archive's externally recorded SHA-256 anchors this manifest.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys

SCHEMA = "STARCORE_R335_PART1_REVIEW_V1"
STATUS = "PART1_REVIEWED_PART2_PENDING"
PLAN_ROOT = "STARCORE_R33_5_20261118"
MANIFEST_NAME = "DELIVERY_MANIFEST.json"
ORIGINAL_SEAL = "verification/SHA256.json"
ARCHIVED_HOST_RUNS = "verification/HOST_RUNS.json"
PART2_MEMBER = "verification/history_r335/host_877ae460/EXACT_EXECUTION_INPUTS.zip"
MAX_JSON_BYTES = 16 * 1024 * 1024


class IntegrityError(ValueError):
    pass


def require(condition: bool, code: str) -> None:
    if not condition:
        raise IntegrityError(code)


def relative(value: object) -> str:
    require(isinstance(value, str) and bool(value) and len(value) <= 4096,
            "RELATIVE_PATH_REQUIRED")
    require("\\" not in value and "\x00" not in value,
            "RELATIVE_PATH_SEPARATOR_OR_NUL")
    require(not PurePosixPath(value).is_absolute()
            and all(part not in ("", ".", "..") for part in value.split("/"))
            and ":" not in value.split("/", 1)[0], "RELATIVE_PATH_ESCAPE")
    return value


def digest_value(value: object) -> str:
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
            "SHA256_REQUIRED")
    return value


def no_symlink_chain(path: Path) -> None:
    for item in (path, *path.parents):
        require(not item.is_symlink(), "SYMLINK_FORBIDDEN:" + str(item))


def checked_file(path: Path, root: Path) -> None:
    no_symlink_chain(path)
    require(path.resolve(strict=True).is_relative_to(root.resolve(strict=True)),
            "FILE_ESCAPES_ROOT:" + str(path))
    require(stat.S_ISREG(path.lstat().st_mode), "REGULAR_FILE_REQUIRED:" + str(path))


def read_file(path: Path, root: Path, *, as_bytes: bool = False):
    checked_file(path, root)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    hasher = hashlib.sha256()
    parts = [] if as_bytes else None
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), "REGULAR_FILE_REQUIRED:" + str(path))
        if as_bytes:
            require(before.st_size <= MAX_JSON_BYTES, "JSON_SIZE_BOUND:" + str(path))
        total = 0
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            total += len(block)
            if as_bytes:
                require(total <= MAX_JSON_BYTES, "JSON_SIZE_BOUND:" + str(path))
                parts.append(block)
            hasher.update(block)
        after = os.fstat(stream.fileno())
    checked_file(path, root)
    current = path.lstat()
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(before, key) == getattr(after, key) == getattr(current, key)
                for key in fields), "FILE_CHANGED_DURING_READ:" + str(path))
    return b"".join(parts) if as_bytes else hasher.hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "DUPLICATE_JSON_KEY:" + key)
        result[key] = value
    return result


def read_json(path: Path, root: Path):
    data = read_file(path, root, as_bytes=True)
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=unique_object)


def tree_files(root: Path) -> set[str]:
    no_symlink_chain(root)
    require(root.is_dir(), "DIRECTORY_REQUIRED:" + str(root))
    result = set()

    def scan_error(error):
        raise error

    for directory, directories, files in os.walk(root, followlinks=False, onerror=scan_error):
        for name in directories:
            path = Path(directory) / name
            no_symlink_chain(path)
            require(stat.S_ISDIR(path.lstat().st_mode), "DIRECTORY_REQUIRED:" + str(path))
            relative(path.relative_to(root).as_posix())
        for name in files:
            path = Path(directory) / name
            checked_file(path, root)
            result.add(relative(path.relative_to(root).as_posix()))
    return result


def hash_map(value: object, label: str) -> dict[str, str]:
    require(isinstance(value, dict), "HASH_MAP_REQUIRED:" + label)
    return {relative(path): digest_value(sha) for path, sha in value.items()}


def records(value: object, label: str, fields: tuple[str, ...]) -> dict[str, dict]:
    require(isinstance(value, list), "RECORD_LIST_REQUIRED:" + label)
    result = {}
    for row in value:
        require(isinstance(row, dict) and all(key in row for key in ("path", *fields)),
                "RECORD_FIELDS_REQUIRED:" + label)
        path = relative(row["path"])
        require(path not in result, "DUPLICATE_RECORD:" + label + ":" + path)
        for key in fields:
            digest_value(row[key])
        result[path] = row
    return result


def verify(manifest_path: Path) -> dict:
    manifest_path = manifest_path.absolute()
    require(manifest_path.name == MANIFEST_NAME, "MANIFEST_FILENAME_REQUIRED")
    review_root = manifest_path.parent
    manifest = read_json(manifest_path, review_root)
    require(isinstance(manifest, dict), "MANIFEST_OBJECT_REQUIRED")
    require(manifest.get("schema") == SCHEMA and manifest.get("status") == STATUS,
            "PART1_REVIEW_IDENTITY")
    require(manifest.get("planRoot") == PLAN_ROOT, "PLAN_ROOT_IDENTITY")
    plan_root = review_root.parent / PLAN_ROOT
    plan_files = hash_map(manifest.get("planFiles"), "planFiles")
    review_files = hash_map(manifest.get("reviewFiles"), "reviewFiles")
    require(MANIFEST_NAME not in review_files, "MANIFEST_SELF_REFERENCE")
    require("verify_part1.py" in review_files, "VERIFIER_NOT_REGISTERED")
    actual_plan = tree_files(plan_root)
    actual_review = tree_files(review_root)
    require(actual_plan == set(plan_files), "PLAN_FILE_SET_MISMATCH")
    require(actual_review == set(review_files) | {MANIFEST_NAME}, "REVIEW_FILE_SET_MISMATCH")
    for path, expected in plan_files.items():
        require(read_file(plan_root / path, plan_root) == expected, "PLAN_FILE_HASH:" + path)
    for path, expected in review_files.items():
        require(read_file(review_root / path, review_root) == expected, "REVIEW_FILE_HASH:" + path)

    seal = manifest.get("originalSeal")
    require(isinstance(seal, dict) and seal.get("path") == ORIGINAL_SEAL,
            "ORIGINAL_SEAL_PATH")
    expected_seal = digest_value(seal.get("sha256"))
    require(plan_files.get(ORIGINAL_SEAL) == expected_seal, "ORIGINAL_SEAL_CHANGED")
    original = hash_map(read_json(plan_root / ORIGINAL_SEAL, plan_root), "originalSeal")
    require(ORIGINAL_SEAL not in original, "ORIGINAL_SEAL_SELF_REFERENCE")
    require(ARCHIVED_HOST_RUNS in original, "ARCHIVED_HOST_RUNS_NOT_IN_ORIGINAL_SEAL")
    require(plan_files.get(ARCHIVED_HOST_RUNS) == original[ARCHIVED_HOST_RUNS],
            "ARCHIVED_HOST_RUNS_CHANGED")

    missing = records(manifest.get("expectedOriginalMissingMembers"), "missing", ("sha256",))
    require(set(missing) == {PART2_MEMBER}, "MISSING_PART2_SET")
    require(set(original) - actual_plan == set(missing), "ORIGINAL_MISSING_MEMBER_SET")
    for path, row in missing.items():
        require(original.get(path) == row["sha256"], "MISSING_MEMBER_ORIGINAL_HASH:" + path)

    modified = records(manifest.get("modifiedOriginalFiles"), "modified",
                       ("beforeSha256", "afterSha256"))
    added = records(manifest.get("addedPlanFiles"), "added", ("sha256",))
    require(not ({ORIGINAL_SEAL, ARCHIVED_HOST_RUNS} & set(modified)),
            "ARCHIVED_EVIDENCE_CANNOT_BE_MODIFIED")
    require(set(modified) <= set(original) - set(missing), "MODIFIED_NOT_ORIGINAL_PRESENT")
    for path, row in modified.items():
        require(row["beforeSha256"] == original[path], "MODIFIED_BEFORE_HASH:" + path)
        require(row["beforeSha256"] != row["afterSha256"], "MODIFIED_NO_CHANGE:" + path)
        require(plan_files[path] == row["afterSha256"], "MODIFIED_AFTER_HASH:" + path)
    for path in set(original) & actual_plan:
        if path not in modified:
            require(plan_files[path] == original[path], "UNREGISTERED_MODIFICATION:" + path)
    actual_added = actual_plan - set(original) - {ORIGINAL_SEAL}
    require(actual_added == set(added), "ADDED_PLAN_FILE_SET_MISMATCH")
    for path, row in added.items():
        require(plan_files[path] == row["sha256"], "ADDED_PLAN_FILE_HASH:" + path)

    return {
        "status": "PART1_INTEGRITY_PASS_PART2_PENDING",
        "scope": "FIRST_PART_BYTES_AND_REPAIR_REGISTRATION_ONLY",
        "planFilesChecked": len(plan_files),
        "reviewFilesChecked": len(review_files),
        "modifiedOriginalFiles": len(modified),
        "addedPlanFiles": len(added),
        "expectedOriginalMissingMembers": sorted(missing),
        "originalSealPreserved": True,
        "archivedHostRunsPreserved": True,
        "hostRunsInterpretation": "ARCHIVED_EVIDENCE_ONLY_NOT_CURRENT_WHOLE_PACKAGE_PASS",
        "wholePackageStatus": "NOT_VERIFIED_PART2_PENDING",
        "currentHostSuitesExecuted": False,
        "apkBuild": "NOT_INFERRED",
        "androidRuntime": "NOT_INFERRED",
        "naturalQuality": "NOT_INFERRED",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path,
                        default=Path(__file__).resolve().parent / MANIFEST_NAME)
    args = parser.parse_args()
    try:
        result = verify(args.manifest)
    except (IntegrityError, OSError, ValueError, TypeError, KeyError) as error:
        print(json.dumps({"status": "PART1_INTEGRITY_FAIL", "reason": str(error),
                          "wholePackageStatus": "NOT_VERIFIED"}, ensure_ascii=False),
              file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
