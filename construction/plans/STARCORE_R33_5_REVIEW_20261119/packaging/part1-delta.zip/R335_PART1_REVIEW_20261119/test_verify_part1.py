#!/usr/bin/env python3
"""Small isolated fixtures for the first-part integrity verifier, never the app."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import verify_part1 as checker


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class Part1IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="r335-part1-verifier-")
        self.base = Path(self.temp.name)
        self.plan = self.base / checker.PLAN_ROOT
        self.review = self.base / "R335_PART1_REVIEW_20261119"
        (self.plan / "verification").mkdir(parents=True)
        self.review.mkdir()
        self.original_body = b"original production payload\n"
        (self.plan / "code.java").write_bytes(self.original_body)
        host = b'{"scope":"HOST_ONLY","runs":{"old":{"exitCode":0}}}\n'
        (self.plan / checker.ARCHIVED_HOST_RUNS).write_bytes(host)
        self.original = {
            "code.java": sha(self.original_body),
            checker.ARCHIVED_HOST_RUNS: sha(host),
            checker.PART2_MEMBER: sha(b"second part remains unavailable"),
        }
        seal = (json.dumps(self.original, sort_keys=True) + "\n").encode()
        (self.plan / checker.ORIGINAL_SEAL).write_bytes(seal)
        verifier = Path(checker.__file__).read_bytes()
        (self.review / "verify_part1.py").write_bytes(verifier)
        self.path = self.review / checker.MANIFEST_NAME
        self.manifest = {
            "schema": checker.SCHEMA,
            "status": checker.STATUS,
            "planRoot": checker.PLAN_ROOT,
            "originalSeal": {"path": checker.ORIGINAL_SEAL, "sha256": sha(seal)},
            "expectedOriginalMissingMembers": [
                {"path": checker.PART2_MEMBER, "sha256": self.original[checker.PART2_MEMBER]}
            ],
            "planFiles": {"code.java": sha(self.original_body),
                          checker.ARCHIVED_HOST_RUNS: sha(host),
                          checker.ORIGINAL_SEAL: sha(seal)},
            "reviewFiles": {"verify_part1.py": sha(verifier)},
            "modifiedOriginalFiles": [],
            "addedPlanFiles": [],
        }
        self.save()

    def tearDown(self):
        self.temp.cleanup()

    def save(self):
        self.path.write_text(json.dumps(self.manifest, ensure_ascii=False, indent=2) + "\n")

    def fails(self, reason):
        with self.assertRaisesRegex(checker.IntegrityError, reason):
            checker.verify(self.path)

    def register_edit(self, path, body):
        (self.plan / path).write_bytes(body)
        self.manifest["planFiles"][path] = sha(body)
        self.manifest["modifiedOriginalFiles"].append(
            {"path": path, "beforeSha256": self.original[path], "afterSha256": sha(body)})
        self.save()

    def test_valid_original_part_preserves_pending_scope(self):
        result = checker.verify(self.path)
        self.assertEqual(result["status"], "PART1_INTEGRITY_PASS_PART2_PENDING")
        self.assertEqual(result["wholePackageStatus"], "NOT_VERIFIED_PART2_PENDING")
        self.assertFalse(result["currentHostSuitesExecuted"])
        self.assertEqual(result["apkBuild"], "NOT_INFERRED")

    def test_registered_production_modification_passes(self):
        self.register_edit("code.java", b"reviewed repair\n")
        self.assertEqual(checker.verify(self.path)["modifiedOriginalFiles"], 1)

    def test_tampered_plan_file_fails(self):
        (self.plan / "code.java").write_bytes(b"tampered")
        self.fails("PLAN_FILE_HASH")

    def test_unregistered_modification_fails_even_with_new_file_hash(self):
        body = b"repair omitted from registry"
        (self.plan / "code.java").write_bytes(body)
        self.manifest["planFiles"]["code.java"] = sha(body)
        self.save()
        self.fails("UNREGISTERED_MODIFICATION")

    def test_wrong_before_hash_fails(self):
        self.register_edit("code.java", b"repair")
        self.manifest["modifiedOriginalFiles"][0]["beforeSha256"] = "0" * 64
        self.save()
        self.fails("MODIFIED_BEFORE_HASH")

    def test_unexpected_plan_file_fails(self):
        (self.plan / "unexpected.txt").write_text("unexpected")
        self.fails("PLAN_FILE_SET_MISMATCH")

    def test_unexpected_review_file_fails(self):
        (self.review / "unexpected.log").write_text("unexpected")
        self.fails("REVIEW_FILE_SET_MISMATCH")

    def test_registered_addition_passes(self):
        body = b"new handoff instructions"
        (self.plan / "new.txt").write_bytes(body)
        self.manifest["planFiles"]["new.txt"] = sha(body)
        self.manifest["addedPlanFiles"] = [{"path": "new.txt", "sha256": sha(body)}]
        self.save()
        self.assertEqual(checker.verify(self.path)["addedPlanFiles"], 1)

    def test_unregistered_addition_fails_even_with_new_file_hash(self):
        body = b"unregistered addition"
        (self.plan / "new.txt").write_bytes(body)
        self.manifest["planFiles"]["new.txt"] = sha(body)
        self.save()
        self.fails("ADDED_PLAN_FILE_SET_MISMATCH")

    def test_original_seal_rewrite_fails(self):
        body = (self.plan / checker.ORIGINAL_SEAL).read_bytes() + b" "
        (self.plan / checker.ORIGINAL_SEAL).write_bytes(body)
        self.manifest["planFiles"][checker.ORIGINAL_SEAL] = sha(body)
        self.save()
        self.fails("ORIGINAL_SEAL_CHANGED")

    def test_archived_host_runs_cannot_be_replaced_by_registered_pass(self):
        self.register_edit(checker.ARCHIVED_HOST_RUNS, b'{"allPassed":true}\n')
        self.fails("ARCHIVED_HOST_RUNS_CHANGED")

    def test_missing_list_cannot_be_dropped(self):
        self.manifest["expectedOriginalMissingMembers"] = []
        self.save()
        self.fails("MISSING_PART2_SET")

    def test_missing_member_sha_must_match_original_seal(self):
        self.manifest["expectedOriginalMissingMembers"][0]["sha256"] = "0" * 64
        self.save()
        self.fails("MISSING_MEMBER_ORIGINAL_HASH")

    def test_missing_original_member_cannot_be_silently_omitted(self):
        (self.plan / "code.java").unlink()
        del self.manifest["planFiles"]["code.java"]
        self.save()
        self.fails("ORIGINAL_MISSING_MEMBER_SET")

    def test_added_second_part_requires_a_different_complete_delivery(self):
        member = self.plan / checker.PART2_MEMBER
        member.parent.mkdir(parents=True)
        body = b"second part remains unavailable"
        member.write_bytes(body)
        self.manifest["planFiles"][checker.PART2_MEMBER] = sha(body)
        self.save()
        self.fails("ORIGINAL_MISSING_MEMBER_SET")

    def test_path_traversal_absolute_and_aliases_are_rejected(self):
        for value in ("../outside", "/tmp/outside", "a/../outside", "a/./b", "a//b", "C:/outside", "a\\b"):
            with self.subTest(path=value):
                bad = deepcopy(self.manifest)
                bad["planFiles"][value] = "0" * 64
                self.path.write_text(json.dumps(bad))
                self.fails("RELATIVE_PATH")

    def test_file_symlink_to_external_file_is_rejected(self):
        outside = self.base / "outside.java"
        outside.write_bytes(self.original_body)
        (self.plan / "code.java").unlink()
        (self.plan / "code.java").symlink_to(outside)
        self.fails("SYMLINK_FORBIDDEN")

    def test_directory_symlink_even_when_unlisted_is_rejected(self):
        outside = self.base / "external"
        outside.mkdir()
        (self.plan / "linked").symlink_to(outside, target_is_directory=True)
        self.fails("SYMLINK_FORBIDDEN")

    def test_changed_review_script_is_rejected(self):
        (self.review / "verify_part1.py").write_bytes(b"changed verifier")
        self.fails("REVIEW_FILE_HASH")

    def test_duplicate_json_keys_are_rejected(self):
        text = self.path.read_text()
        self.path.write_text(text.replace('"schema":', '"schema": "other", "schema":', 1))
        self.fails("DUPLICATE_JSON_KEY")

    def test_duplicate_modified_records_are_rejected(self):
        self.register_edit("code.java", b"repair")
        self.manifest["modifiedOriginalFiles"] *= 2
        self.save()
        self.fails("DUPLICATE_RECORD")

    def test_self_referential_manifest_is_rejected(self):
        self.manifest["reviewFiles"][checker.MANIFEST_NAME] = "0" * 64
        self.save()
        self.fails("MANIFEST_SELF_REFERENCE")

    def test_full_package_status_cannot_replace_first_part_status(self):
        self.manifest["status"] = "WHOLE_PACKAGE_PASS"
        self.save()
        self.fails("PART1_REVIEW_IDENTITY")


if __name__ == "__main__":
    unittest.main(verbosity=2)
