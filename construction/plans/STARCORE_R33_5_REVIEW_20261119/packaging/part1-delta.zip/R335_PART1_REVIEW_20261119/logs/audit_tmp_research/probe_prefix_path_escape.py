#!/usr/bin/env python3
"""Run the actual prefix copy function against an isolated path-escape fixture.

No real source, plan payload, generated code, or external command is modified/run.
Before the fix this emits outsideCandidateModified=true. After the fix it should
emit refusedBeforeMutation=true. This probe does not assert Android correctness.
"""

from pathlib import Path
import argparse
import hashlib
import json
import runpy
import sys
import tempfile
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runner', type=Path, default=Path(__file__).resolve().parents[1]
                        / 'work/STARCORE_R33_5_20261118/verification/run_stage_prefix_r335.py')
    args = parser.parse_args()
    runner = args.runner.resolve()
    digest = lambda data: hashlib.sha256(data).hexdigest()
    with tempfile.TemporaryDirectory(prefix='r335-prefix-path-review-') as temporary:
        root = Path(temporary)
        source = root / 'source'
        plan = root / 'plan'
        work = root / 'work'
        for directory in [source / 'release', plan / 'control', work]:
            directory.mkdir(parents=True, exist_ok=True)
        (source / 'release/release_manifest.json').write_text('{}\n')
        (plan / 'control/APPLY_MANIFEST_R335.json').write_text('{}\n')
        for dependency in ['android.jar', 'annotation.jar']:
            (root / dependency).write_bytes(b'isolated-fixture-never-compiled')
        argv = [str(runner), '--baseline-source', str(source), '--work-dir', str(work),
                '--plan-root', str(plan), '--android-jar', str(root / 'android.jar'),
                '--annotation-jar', str(root / 'annotation.jar'), '--java', sys.executable]
        prior_path = list(sys.path)
        sys.path.insert(0, str(runner.parent))
        try:
            with patch.object(sys, 'argv', argv):
                namespace = runpy.run_path(str(runner), run_name='independent_prefix_audit')
        finally:
            sys.path[:] = prior_path
        candidate = work / 'prefix_candidate'
        candidate.mkdir()
        outside = work / 'outside.txt'
        outside.write_bytes(b'original')
        (plan / 'payload.txt').write_bytes(b'changed')
        row = {'path': '../outside.txt', 'payload': 'payload.txt',
               'beforeSha256': digest(b'original'), 'afterSha256': digest(b'changed')}
        external_commands = []

        def stop(*positional, **keyword):
            external_commands.append(positional[0] if positional else None)
            raise RuntimeError('PROBE_STOP_AFTER_FILE_COPY')

        failure = None
        with patch.object(namespace['run_stage'].__globals__['subprocess'], 'run', side_effect=stop):
            try:
                namespace['run_stage']('B01', [row])
            except Exception as error:
                failure = type(error).__name__ + ': ' + str(error)
        changed = outside.read_bytes() != b'original'
        print(json.dumps({'scope': 'EXACT_RUN_STAGE_ISOLATED_PATH_ESCAPE_PROBE',
                          'runner': str(runner), 'runnerSha256': digest(runner.read_bytes()),
                          'path': row['path'], 'outsideCandidateModified': changed,
                          'refusedBeforeMutation': not changed and failure is not None,
                          'externalCommandsExecuted': False,
                          'externalCommandsIntercepted': len(external_commands),
                          'failure': failure}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
