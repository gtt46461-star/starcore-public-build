"""Host regressions for exact baseline/source/archive gating; no production claim."""
from pathlib import Path
import copy
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import verify_baseline_source_r335 as verify


class BaselineSource(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='r335-baseline-guard-')
        self.root = Path(self.temporary.name)
        self.source = self.root/'source'
        self.source.mkdir()
        (self.source/'release').mkdir()
        (self.source/'release/release_manifest.json').write_text('{"fixture":true}\n')
        (self.source/'scripts').mkdir()
        (self.source/'scripts/generator.py').write_text('print("synthetic fixture only")\n')
        (self.source/'app').mkdir()
        (self.source/'app/source.java').write_text('class Fixture {}\n')

    def tearDown(self):
        self.temporary.cleanup()

    def git(self, *args):
        return verify.checkout_verifier().git(self.source, *args)

    def commit(self):
        self.git('add', '.')
        self.git('-c', 'user.name=fixture', '-c', 'user.email=fixture@localhost',
                 '-c', 'commit.gpgsign=false', 'commit', '--quiet', '-m', 'fixture')
        return self.git('rev-parse', 'HEAD').decode().strip()

    def git_fixture(self):
        self.git('init', '--quiet')
        return self.commit()

    def archive_fixture(self):
        archive = self.root/'source.zip'
        with zipfile.ZipFile(archive, 'w') as output:
            for source in sorted(self.source.rglob('*')):
                if source.is_file():
                    output.write(source, 'fixture-root/'+source.relative_to(self.source).as_posix())
        return archive, {'sourceCommit': verify.BASE, 'sourceArchiveBytes': archive.stat().st_size,
                         'sourceArchiveSha256': verify.sha_file(archive)}

    def test_exact_synthetic_git_tree_and_copy_are_bound(self):
        base = self.git_fixture()
        with patch.object(verify, 'BASE', base):
            receipt = verify.verify_source(self.source)
        copied = self.root/'snapshot'
        shutil.copytree(self.source, copied, symlinks=True,
                        ignore=lambda directory,names:verify.copy_ignore(directory,names,self.source))
        self.assertTrue(verify.verify_snapshot(copied, receipt))
        self.assertEqual(receipt['copiedMembers'], 3)
        self.assertFalse(receipt['productionAncestryGranted'])

    def test_wrong_commit_is_rejected(self):
        base = self.git_fixture()
        (self.source/'app/source.java').write_text('class Changed {}')
        self.commit()
        with patch.object(verify, 'BASE', base), self.assertRaisesRegex(ValueError, 'EXACT_033_BASELINE_HEAD_REQUIRED'):
            verify.verify_source(self.source)

    def test_assume_unchanged_does_not_hide_changed_generator(self):
        base = self.git_fixture()
        self.git('update-index', '--assume-unchanged', '--', 'scripts/generator.py')
        (self.source/'scripts/generator.py').write_text('raise SystemExit(0)\n')
        with patch.object(verify, 'BASE', base), self.assertRaisesRegex(ValueError, 'HEAD_FILE_BYTES_MISMATCH'):
            verify.verify_source(self.source)

    def test_extra_untracked_root_file_is_rejected(self):
        base = self.git_fixture()
        (self.source/'extra-build-input.txt').write_text('unregistered')
        with patch.object(verify, 'BASE', base), self.assertRaisesRegex(ValueError, 'UNTRACKED_OR_MISSING_BASELINE_COPY_INPUT'):
            verify.verify_source(self.source)

    def test_exact_archive_verifies_all_members_without_git(self):
        archive, identity = self.archive_fixture()
        with patch.object(verify, 'archive_identity', return_value=identity):
            receipt = verify.verify_source(self.source, archive)
        self.assertEqual(receipt['archiveMembersVerified'], 3)
        self.assertEqual(receipt['route'], 'EXACT_PINNED_SOURCE_ARCHIVE')
        self.assertFalse(receipt['productionAncestryGranted'])
        self.assertFalse((self.source/'.git').exists())

    def test_changed_archive_bytes_are_rejected(self):
        archive, identity = self.archive_fixture()
        with archive.open('ab') as output:
            output.write(b'altered')
        with patch.object(verify, 'archive_identity', return_value=identity), self.assertRaisesRegex(ValueError, 'EXACT_033_SOURCE_ARCHIVE_REQUIRED'):
            verify.verify_source(self.source, archive)

    def test_changed_uncontrolled_source_member_is_rejected(self):
        archive, identity = self.archive_fixture()
        (self.source/'app/source.java').write_text('class Changed {}')
        with patch.object(verify, 'archive_identity', return_value=identity), self.assertRaisesRegex(ValueError, 'BASELINE_ARCHIVE_MEMBER_DIFFERENT'):
            verify.verify_source(self.source, archive)

    def test_archive_extra_source_file_is_rejected(self):
        archive, identity = self.archive_fixture()
        (self.source/'scripts/new_generator.py').write_text('new')
        with patch.object(verify, 'archive_identity', return_value=identity), self.assertRaisesRegex(ValueError, 'UNREGISTERED_OR_MISSING_BASELINE_ARCHIVE_INPUT'):
            verify.verify_source(self.source, archive)

    def test_archive_missing_source_member_is_rejected(self):
        archive, identity = self.archive_fixture()
        (self.source/'app/source.java').unlink()
        with patch.object(verify, 'archive_identity', return_value=identity), self.assertRaisesRegex(ValueError, 'BASELINE_ARCHIVE_MEMBER_MISSING'):
            verify.verify_source(self.source, archive)

    def test_snapshot_change_is_rejected_before_execution(self):
        archive, identity = self.archive_fixture()
        with patch.object(verify, 'archive_identity', return_value=identity):
            receipt = verify.verify_source(self.source, archive)
        copied = self.root/'snapshot'
        shutil.copytree(self.source, copied)
        (copied/'scripts/generator.py').write_text('changed after verification')
        with self.assertRaisesRegex(ValueError, 'BASELINE_SNAPSHOT_BYTES_CHANGED'):
            verify.verify_snapshot(copied, receipt)

    @unittest.skipIf(os.name == 'nt', 'POSIX executable-mode fixture')
    def test_snapshot_executable_mode_change_is_rejected(self):
        archive, identity = self.archive_fixture()
        with patch.object(verify, 'archive_identity', return_value=identity):
            receipt = verify.verify_source(self.source, archive)
        copied = self.root/'snapshot'
        shutil.copytree(self.source, copied)
        script = copied/'scripts/generator.py'
        script.chmod(script.stat().st_mode ^ 0o100)
        with self.assertRaisesRegex(ValueError, 'BASELINE_SNAPSHOT_BYTES_CHANGED'):
            verify.verify_snapshot(copied, receipt)

    def test_non_git_source_never_executes_its_generator(self):
        marker = self.root/'unverified-generator-ran'
        (self.source/'scripts/verify_catalog_assets_cp12.py').write_text(
            'from pathlib import Path\nPath('+repr(str(marker))+').write_text("ran")\n')
        for name in ['android.jar', 'annotation.jar']:
            (self.root/name).write_bytes(b'not-real-dependencies')
        command = [sys.executable, '-B', str(verify.PACKAGE/'verification/run_stage_prefix_r335.py'),
                   '--baseline-source', str(self.source), '--work-dir', str(self.root/'work'),
                   '--android-jar', str(self.root/'android.jar'),
                   '--annotation-jar', str(self.root/'annotation.jar'), '--java', sys.executable]
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('GIT_FAILED:rev-parse', result.stderr)
        self.assertFalse(marker.exists())
        self.assertFalse((self.root/'work').exists())


class InstallManifest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='r335-install-boundary-')
        self.root = Path(self.temporary.name)
        self.plan = self.root/'plan';self.plan.mkdir()
        self.candidate = self.root/'candidate';self.candidate.mkdir()
        (self.plan/'before.txt').write_bytes(b'before')
        (self.plan/'after.txt').write_bytes(b'after')
        (self.candidate/'source.txt').write_bytes(b'before')
        self.outside = self.root/'outside.txt';self.outside.write_bytes(b'before')
        self.row = {'path':'source.txt','payload':'after.txt','beforeFile':'before.txt',
                    'beforeSha256':hashlib.sha256(b'before').hexdigest(),
                    'afterSha256':hashlib.sha256(b'after').hexdigest(),'action':'REPLACE'}
        self.manifest = {'schema':'STARCORE_R335_COMPLETE_AFTER_IMAGES_1','sourceBaseline':verify.BASE,
                         'planRevision':'R33.5','batchCount':9,'fileChangeCount':1,'distinctPathCount':1,
                         'batches':[{'id':stage,'files':[self.row.copy()] if stage=='P00' else []}
                                    for stage in verify.STAGES]}

    def tearDown(self):
        self.temporary.cleanup()

    def unchanged(self):
        self.assertEqual(self.outside.read_bytes(), b'before')
        self.assertEqual((self.candidate/'source.txt').read_bytes(), b'before')

    def test_valid_complete_manifest_and_candidate_copy(self):
        self.assertEqual(verify.validate_install_manifest(self.plan,self.manifest)['fileChanges'],1)
        verify.apply_stage_files(self.plan,self.candidate,'P00',[self.row])
        self.assertEqual((self.candidate/'source.txt').read_bytes(),b'after')
        self.assertEqual(self.outside.read_bytes(),b'before')

    def test_unsafe_repository_paths_refused_without_any_write(self):
        for name in ['../outside.txt',str(self.outside),'C:/outside.txt','C:outside.txt',
                     '..\\outside.txt','.git/config','./source.txt','sub//file.txt']:
            with self.subTest(name=name):
                row=dict(self.row,path=name)
                manifest=copy.deepcopy(self.manifest);manifest['batches'][0]['files']=[row]
                with self.assertRaises(ValueError):verify.validate_install_manifest(self.plan,manifest)
                with self.assertRaises(ValueError):verify.apply_stage_files(self.plan,self.candidate,'P00',[row])
                self.unchanged()

    def test_escaping_payload_refused_without_any_write(self):
        for name in ['../outside.txt',str(self.outside),'C:/payload.txt','..\\outside.txt']:
            with self.subTest(name=name):
                row=dict(self.row,payload=name,afterSha256=self.row['beforeSha256'])
                manifest=copy.deepcopy(self.manifest);manifest['batches'][0]['files']=[row]
                with self.assertRaises(ValueError):verify.validate_install_manifest(self.plan,manifest)
                with self.assertRaises(ValueError):verify.apply_stage_files(self.plan,self.candidate,'P00',[row])
                self.unchanged()

    def test_target_parent_symlink_refused(self):
        (self.candidate/'linked').symlink_to(self.root,target_is_directory=True)
        row=dict(self.row,path='linked/outside.txt')
        with self.assertRaises(ValueError):verify.apply_stage_files(self.plan,self.candidate,'P00',[row])
        self.unchanged()

    def test_target_leaf_symlink_refused(self):
        (self.candidate/'linked.txt').symlink_to(self.outside)
        row=dict(self.row,path='linked.txt')
        with self.assertRaises(ValueError):verify.apply_stage_files(self.plan,self.candidate,'P00',[row])
        self.unchanged()

    def test_payload_leaf_and_parent_symlinks_refused(self):
        (self.plan/'linked.txt').symlink_to(self.plan/'after.txt')
        (self.plan/'linked-dir').symlink_to(self.plan,target_is_directory=True)
        for name in ['linked.txt','linked-dir/after.txt']:
            with self.subTest(name=name):
                row=dict(self.row,payload=name)
                manifest=copy.deepcopy(self.manifest);manifest['batches'][0]['files']=[row]
                with self.assertRaises(ValueError):verify.validate_install_manifest(self.plan,manifest)
                with self.assertRaises(ValueError):verify.apply_stage_files(self.plan,self.candidate,'P00',[row])
                self.unchanged()

    def test_stage_escape_and_wrong_stage_order_refused(self):
        with self.assertRaisesRegex(ValueError,'PREFIX_INVALID_STAGE'):
            verify.apply_stage_files(self.plan,self.candidate,'../../outside',[self.row])
        manifest=copy.deepcopy(self.manifest);manifest['batches'][0]['id']='../../outside'
        with self.assertRaisesRegex(ValueError,'PREFIX_INSTALL_STAGE_ORDER'):
            verify.validate_install_manifest(self.plan,manifest)
        self.unchanged()

    def test_manifest_identity_and_hash_changes_refused(self):
        for key,value in [('schema','wrong'),('sourceBaseline','0'*40),('planRevision','R33.4')]:
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'PREFIX_INSTALL_MANIFEST_IDENTITY'):
                verify.validate_install_manifest(self.plan,dict(self.manifest,**{key:value}))
        (self.plan/'after.txt').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'PREFIX_INSTALL_PAYLOAD_HASH'):
            verify.validate_install_manifest(self.plan,self.manifest)
        self.unchanged()

    def test_later_invalid_file_cannot_partially_apply_batch(self):
        row=dict(self.row,path='../outside.txt')
        with self.assertRaises(ValueError):
            verify.apply_stage_files(self.plan,self.candidate,'P00',[self.row,row])
        self.unchanged()


if __name__ == '__main__':
    unittest.main(verbosity=2)
