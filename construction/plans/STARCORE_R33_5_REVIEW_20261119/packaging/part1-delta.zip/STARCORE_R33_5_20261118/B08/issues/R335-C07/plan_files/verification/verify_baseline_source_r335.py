"""Verify every source leaf before any 033 prefix generator is executed.

The archive route proves source bytes only; it never creates Git history or
satisfies the production release ancestry gate.
"""
from pathlib import Path, PurePosixPath
import hashlib
import importlib.util
import json
import os
import re
import shutil
import stat
import zipfile

PACKAGE = Path(__file__).resolve().parents[1]
BASE = 'bb7b49bbcc9266bad548ec37e71403256fc06a4d'
STAGES = ['P00'] + [f'B{i:02d}' for i in range(1, 9)]


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha_file(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            result.update(block)
    return result.hexdigest()


def source_relative(name):
    require(isinstance(name, str) and name, 'BASELINE_MEMBER_STRING_REQUIRED')
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and path.as_posix() == name
            and '\\' not in name and not re.match(r'^[A-Za-z]:', name)
            and not any(x in ('.', '..', '.git') for x in path.parts),
            'UNSAFE_BASELINE_MEMBER:' + name)
    return path


def copied_member(name):
    parts = PurePosixPath(name).parts
    return not any(x in ('.git', '.gradle', '__pycache__') for x in parts) \
        and not (len(parts) >= 2 and parts[:2] == ('app', 'build')) \
        and not name.endswith(('.pyc', '.pyo'))


def copy_ignore(directory, names, root):
    relative = Path(directory).relative_to(root)
    return [name for name in names if not copied_member((relative / name).as_posix())]


def materialized_leaves(root):
    """Inventory exactly the leaves that the prefix materializer will copy."""
    found = set()
    for directory, names, files in os.walk(root, followlinks=False):
        base = Path(directory)
        for name in list(names):
            relative = (base / name).relative_to(root).as_posix()
            if not copied_member(relative):
                names.remove(name)
            elif (base / name).is_symlink():
                found.add(relative)
                names.remove(name)
        for name in files:
            relative = (base / name).relative_to(root).as_posix()
            if copied_member(relative):
                found.add(relative)
    return found


def leaf_record(path):
    observed = path.lstat()
    if stat.S_ISLNK(observed.st_mode):
        data = os.readlink(os.fsencode(path))
        return {'kind': 'symlink', 'sha256': hashlib.sha256(data).hexdigest()}
    require(stat.S_ISREG(observed.st_mode), 'BASELINE_NONREGULAR_FILE:' + str(path))
    return {'kind': 'file', 'sha256': sha_file(path),
            'executable': bool(observed.st_mode & stat.S_IXUSR)}


def git_leaf_record(path, mode):
    if mode == '120000':
        require(path.is_symlink(), 'BASELINE_LINK_CHANGED_TYPE:' + str(path))
        data = os.readlink(os.fsencode(path))
        oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        return oid, {'kind': 'symlink', 'sha256': hashlib.sha256(data).hexdigest()}
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
    with os.fdopen(os.open(path, flags), 'rb') as stream:
        metadata = os.fstat(stream.fileno())
        require(stat.S_ISREG(metadata.st_mode), 'BASELINE_FILE_CHANGED_TYPE:' + str(path))
        if os.name != 'nt':
            require(bool(metadata.st_mode & stat.S_IXUSR) == (mode == '100755'),
                    'BASELINE_FILE_MODE_CHANGED:' + str(path))
        blob = hashlib.sha1(b'blob ' + str(metadata.st_size).encode() + b'\0')
        digest = hashlib.sha256()
        total = 0
        for block in iter(lambda: stream.read(1 << 20), b''):
            total += len(block)
            blob.update(block)
            digest.update(block)
        require(total == metadata.st_size, 'BASELINE_FILE_LENGTH_CHANGED:' + str(path))
    return blob.hexdigest(), {'kind': 'file', 'sha256': digest.hexdigest(),
                             'executable': bool(metadata.st_mode & stat.S_IXUSR)}


def checkout_verifier():
    path = PACKAGE / 'P00/after_full/tools/r33/verify_plan_binding.py'
    spec = importlib.util.spec_from_file_location('r335_baseline_checkout_binding', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_git_source(source):
    binding = checkout_verifier()
    require(Path(binding.git(source, 'rev-parse', '--show-toplevel').decode().strip()).resolve() == source,
            'EXACT_BASELINE_REPOSITORY_ROOT_REQUIRED')
    require(binding.git(source, 'rev-parse', 'HEAD').decode().strip() == BASE,
            'EXACT_033_BASELINE_HEAD_REQUIRED')
    # This checks every tracked raw blob, executable mode and safe link target,
    # independently of assume-unchanged/skip-worktree index flags.
    checked = binding.verify_checkout_bytes(source, BASE)
    records = {}
    for raw in binding.git(source, 'ls-tree', '-r', '-z', '--full-tree', BASE).split(b'\0'):
        if not raw:
            continue
        metadata, encoded = raw.split(b'\t', 1)
        mode, kind, expected = metadata.decode('ascii').split()
        name = os.fsdecode(encoded)
        source_relative(name)
        require(kind == 'blob' and mode in ('100644', '100755', '120000'), 'BASELINE_TREE_ENTRY:' + name)
        leaf = source / name
        # Recheck the blob identity while forming the snapshot digest so an
        # edit between the initial checkout check and this read cannot pass.
        actual, record = git_leaf_record(leaf, mode)
        require(actual == expected, 'BASELINE_CHANGED_DURING_VERIFICATION:' + name)
        if copied_member(name):
            records[name] = record
    require(materialized_leaves(source) == set(records), 'UNTRACKED_OR_MISSING_BASELINE_COPY_INPUT')
    return records, {'route': 'EXACT_GIT_CHECKOUT', 'sourceCommit': BASE,
                     'sourceTree': binding.git(source, 'rev-parse', BASE + '^{tree}').decode().strip(),
                     'trackedFiles': checked['trackedFiles'], 'productionAncestryGranted': False}


def archive_identity():
    identity = json.loads((PACKAGE / 'evidence/R335_SOURCE_BASELINE_VERIFICATION.json').read_text())
    require(identity.get('sourceCommit') == BASE
            and re.fullmatch('[a-f0-9]{64}', str(identity.get('sourceArchiveSha256')))
            and type(identity.get('sourceArchiveBytes')) is int and identity['sourceArchiveBytes'] > 0,
            'PINNED_033_SOURCE_ARCHIVE_IDENTITY_REQUIRED')
    return identity


def verify_archive_source(source, archive):
    identity = archive_identity()
    archive = Path(archive).resolve()
    require(archive.is_file() and archive.stat().st_size == identity['sourceArchiveBytes']
            and sha_file(archive) == identity['sourceArchiveSha256'], 'EXACT_033_SOURCE_ARCHIVE_REQUIRED')
    require(not archive.is_relative_to(source), 'BASELINE_ARCHIVE_MUST_BE_OUTSIDE_SOURCE')
    records = {}
    names = set()
    archive_prefix = None
    file_count = 0
    with zipfile.ZipFile(archive) as package:
        for info in package.infolist():
            raw_name = info.filename[:-1] if info.is_dir() else info.filename
            relative = source_relative(raw_name)
            require(info.filename not in names, 'DUPLICATE_BASELINE_ARCHIVE_MEMBER')
            names.add(info.filename)
            if archive_prefix is None:
                archive_prefix = relative.parts[0]
            require(relative.parts[0] == archive_prefix, 'SINGLE_BASELINE_ARCHIVE_ROOT_REQUIRED')
            if info.is_dir():
                continue
            require(len(relative.parts) > 1, 'BASELINE_ARCHIVE_ROOT_FILE')
            name = PurePosixPath(*relative.parts[1:]).as_posix()
            require(name not in records, 'DUPLICATE_BASELINE_SOURCE_MEMBER:' + name)
            mode = info.external_attr >> 16
            kind = 'symlink' if stat.S_ISLNK(mode) else 'file'
            require(kind == 'symlink' or stat.S_IFMT(mode) in (0, stat.S_IFREG),
                    'BASELINE_ARCHIVE_NONREGULAR_MEMBER:' + name)
            digest = hashlib.sha256()
            with package.open(info) as stream:
                for block in iter(lambda: stream.read(1 << 20), b''):
                    digest.update(block)
            expected = {'kind': kind, 'sha256': digest.hexdigest()}
            leaf = source / name
            require(not any(p.is_symlink() for p in leaf.parents if p != source and p.is_relative_to(source)),
                    'BASELINE_SYMLINK_PARENT:' + name)
            require(leaf.exists() or leaf.is_symlink(), 'BASELINE_ARCHIVE_MEMBER_MISSING:' + name)
            observed = leaf_record(leaf)
            require(all(observed.get(key) == value for key, value in expected.items()),
                    'BASELINE_ARCHIVE_MEMBER_DIFFERENT:' + name)
            # ZIP extraction tools vary in POSIX mode handling. Bind the
            # verified extracted tree's actual mode for the subsequent copy;
            # this is not a claim that a ZIP supplied Git executable metadata.
            expected = observed
            if kind == 'symlink':
                require(not Path(os.readlink(leaf)).is_absolute() and leaf.resolve().is_relative_to(source),
                        'BASELINE_SOURCE_SYMLINK_ESCAPE:' + name)
            records[name] = expected
            file_count += 1
    require(file_count > 0, 'EMPTY_BASELINE_SOURCE_ARCHIVE')
    copied = {name: value for name, value in records.items() if copied_member(name)}
    require(materialized_leaves(source) == set(copied), 'UNREGISTERED_OR_MISSING_BASELINE_ARCHIVE_INPUT')
    return copied, {'route': 'EXACT_PINNED_SOURCE_ARCHIVE', 'sourceCommit': BASE,
                    'sourceArchiveSha256': identity['sourceArchiveSha256'],
                    'sourceArchiveBytes': identity['sourceArchiveBytes'], 'archiveMembersVerified': file_count,
                    'productionAncestryGranted': False}


def verify_source(source, archive=None):
    source = Path(source).resolve()
    require(source.is_dir(), 'BASELINE_SOURCE_DIRECTORY_REQUIRED')
    if archive is None:
        records, receipt = verify_git_source(source)
    else:
        records, receipt = verify_archive_source(source, archive)
    receipt.update(schema='R335_EXACT_BASELINE_SOURCE_1',
                   scope='ALL_SOURCE_MEMBERS_BEFORE_HOST_PREFIX_EXECUTION_NOT_PRODUCTION_ANCESTRY',
                   copiedMembers=len(records), members=records)
    receipt['copiedMembersSha256'] = hashlib.sha256(json.dumps(records, sort_keys=True,
                                                             separators=(',', ':')).encode()).hexdigest()
    return receipt


def verify_snapshot(snapshot, receipt):
    snapshot = Path(snapshot).resolve()
    expected = receipt['members']
    require(materialized_leaves(snapshot) == set(expected), 'BASELINE_SNAPSHOT_MEMBER_SET_CHANGED')
    for name, record in expected.items():
        require(leaf_record(snapshot / name) == record, 'BASELINE_SNAPSHOT_BYTES_CHANGED:' + name)
    return True


def contained_regular(root, name, must_exist):
    root = Path(root).resolve()
    relative = source_relative(name)
    path = root.joinpath(*relative.parts)
    require(path.resolve().is_relative_to(root), 'INSTALL_PATH_ESCAPES_ROOT:' + name)
    require(not path.is_symlink()
            and not any(p.is_symlink() for p in path.parents if p != root and p.is_relative_to(root)),
            'INSTALL_SYMLINK_PATH:' + name)
    if path.exists():
        require(stat.S_ISREG(path.lstat().st_mode), 'INSTALL_REGULAR_FILE_REQUIRED:' + name)
    else:
        require(not must_exist, 'INSTALL_SOURCE_FILE_MISSING:' + name)
    return path


def validate_install_manifest(plan, manifest):
    require(isinstance(manifest, dict)
            and manifest.get('schema') == 'STARCORE_R335_COMPLETE_AFTER_IMAGES_1'
            and manifest.get('sourceBaseline') == BASE and manifest.get('planRevision') == 'R33.5',
            'PREFIX_INSTALL_MANIFEST_IDENTITY')
    batches = manifest.get('batches')
    require(isinstance(batches, list) and len(batches) == len(STAGES)
            and all(isinstance(row, dict) for row in batches)
            and [row.get('id') for row in batches] == STAGES
            and manifest.get('batchCount') == len(STAGES), 'PREFIX_INSTALL_STAGE_ORDER')
    previous = {}
    count = 0
    for batch in batches:
        require(isinstance(batch.get('files'), list), 'PREFIX_INSTALL_FILES_LIST')
        seen = set()
        for row in batch['files']:
            require(isinstance(row, dict), 'PREFIX_INSTALL_FILE_RECORD')
            name = row.get('path')
            source_relative(name)
            require(name not in seen, 'PREFIX_INSTALL_DUPLICATE_PATH:' + name)
            seen.add(name)
            before, after = row.get('beforeSha256'), row.get('afterSha256')
            require(isinstance(after, str) and re.fullmatch('[a-f0-9]{64}', after)
                    and (before == 'NEW' or isinstance(before, str) and re.fullmatch('[a-f0-9]{64}', before)),
                    'PREFIX_INSTALL_DIGEST:' + name)
            require(row.get('action') == ('ADD' if before == 'NEW' else 'REPLACE'),
                    'PREFIX_INSTALL_ACTION:' + name)
            source = contained_regular(plan, row.get('payload'), True)
            require(sha_file(source) == after, 'PREFIX_INSTALL_PAYLOAD_HASH:' + name)
            if before == 'NEW':
                require(row.get('beforeFile') is None, 'PREFIX_INSTALL_NEW_BEFORE_FILE:' + name)
            else:
                original = contained_regular(plan, row.get('beforeFile'), True)
                require(sha_file(original) == before, 'PREFIX_INSTALL_BEFORE_HASH:' + name)
            if row.get('reviewedSource'):
                reviewed = contained_regular(plan, row['reviewedSource'], True)
                require(sha_file(reviewed) == after, 'PREFIX_INSTALL_REVIEWED_SOURCE_HASH:' + name)
            if name in previous:
                require(previous[name] == before, 'PREFIX_INSTALL_SHARED_PATH_CHAIN:' + name)
            previous[name] = after
            count += 1
    require(manifest.get('fileChangeCount') == count and manifest.get('distinctPathCount') == len(previous),
            'PREFIX_INSTALL_MANIFEST_COUNTS')
    return {'stages': len(batches), 'fileChanges': count, 'distinctPaths': len(previous)}


def apply_stage_files(plan, candidate, stage, files):
    require(stage in STAGES or stage == 'BASELINE033' and files == [], 'PREFIX_INVALID_STAGE')
    require(isinstance(files, list), 'PREFIX_INSTALL_FILES_LIST')
    prepared = []
    for row in files:
        source = contained_regular(plan, row['payload'], True)
        target = contained_regular(candidate, row['path'], False)
        require(sha_file(source) == row['afterSha256'], 'INPUT_SHA_CHANGED:' + row['path'])
        before = sha_file(target) if target.is_file() else 'NEW'
        require(before == row['beforeSha256'], 'PREFIX_BEFORE_MISMATCH:' + stage + ':' + row['path'])
        prepared.append(row)
    for row in prepared:
        # Repeat boundaries at the actual copy, even after manifest/preflight
        # verification; never follow a target leaf or parent symlink.
        source = contained_regular(plan, row['payload'], True)
        target = contained_regular(candidate, row['path'], False)
        target.parent.mkdir(parents=True, exist_ok=True)
        source = contained_regular(plan, row['payload'], True)
        target = contained_regular(candidate, row['path'], False)
        require(sha_file(source) == row['afterSha256'], 'INPUT_SHA_CHANGED:' + row['path'])
        before = sha_file(target) if target.is_file() else 'NEW'
        require(before == row['beforeSha256'], 'PREFIX_BEFORE_MISMATCH:' + stage + ':' + row['path'])
        shutil.copyfile(source, target)
        require(sha_file(target) == row['afterSha256'], 'PREFIX_AFTER_COPY_MISMATCH:' + row['path'])
