package android.os; public final class SystemClock { public static long elapsedRealtime(){return 0;} }
