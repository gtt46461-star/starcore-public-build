package com.ethk3.novaonepro.strategyv2;

import android.app.job.*;
import android.os.*;
import com.ethk3.novaonepro.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Main callbacks only start/cancel a worker. Each numeric slice is <=2 s and checkpointed. */
public final class ReplayBurstJobServiceSU1 extends JobService {
    private static final AtomicBoolean RUNNING=new AtomicBoolean();
    private final ConcurrentHashMap<JobParameters,AtomicBoolean> active=new ConcurrentHashMap<>();
    private final ExecutorService worker=Executors.newSingleThreadExecutor(r->new Thread(r,"su1-charging-replay"));
    @Override public boolean onStartJob(JobParameters params){
        AtomicBoolean cancelled=new AtomicBoolean();active.put(params,cancelled);
        worker.execute(()->{
            boolean retry=true;
            if(!RUNNING.compareAndSet(false,true)){finish(params,cancelled,true);return;}
            DbStore store=null;
            try{
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                if(!new ServiceHeartbeatStore(getApplicationContext()).isUserEnabled()){retry=false;return;}
                store=new DbStore(getApplicationContext());long stop=SystemClock.elapsedRealtime()+60000;
                while(!cancelled.get()&&SystemClock.elapsedRealtime()<stop&&!StrategySchemaSU1.ready(store.readable())){
                    if(RealtimePressureGateR811.isUnderPressure()||SettlementExecutionGateR819.isActive())return;
                    ResearchSchemaCoordinatorR926.ensureToReady(store.coordinatorForResearchR952(),8);
                }
                if(!StrategySchemaSU1.ready(store.readable()))return;
                if(StrategyRepositorySU1.exists(store.readable(),"SELECT 1 FROM su1_runtime_control WHERE singleton=1 AND mode='DISABLED' AND reason='USER_CONTROL'")){retry=false;return;}
                Models.Draw canonicalLatest=store.getLatestDraw();if(canonicalLatest!=null)KernelTransitionSU1.ensure(store,LiveShadowLoopSU1.sequence(canonicalLatest.issue));
                LiveShadowLoopSU1.recover(store,32);
                EvidenceLoopSU1.recover(store);
                EvidenceQualitySU1.maintain(store);
                SealedPlannerSU1.maintain(store);
                CalibrationPipelineSU1.maintain(store);
                CertificateSU1.maintain(store);
                MainlineHeadSU1.maintain(store);
                ArchiveStoreSU1.maintain(store);
                // R13-P07: SU2 schema, retention, league choice, certificates and continuous creation
                if(!StrategySchemaSU2.ready(store.readable()))store.coordinatorForResearchR952().runAtomicWriteOrThrowF01("SU2_SCHEMA",db->{StrategySchemaSU2.ensure(db);return 0;});
                ProgramModelSU2.register();
                IncumbentLoopSU2.seed(store,1);
                Models.Draw su2Latest=store.getLatestDraw();
                if(su2Latest!=null&&TargetIssueResolver.isValid(su2Latest.issue)){
                    final long su2Seq=LiveShadowLoopSU1.sequence(su2Latest.issue)+1;final String su2Target=TargetIssueResolver.next(su2Latest.issue).targetIssue;
                    // Fold diagnosis statistics before raw decision retention removes old rows.
                    MatrixStoreSU2.maintain(store,su2Target);
                    DiagnosisStoreSU2.maintain(store,su2Target);
                    store.coordinatorForResearchR952().runAtomicWriteOrThrowF01("SU2_RETENTION",db->{com.ethk3.novaonepro.RetentionRulesSU2.foldDecisions(db,su2Seq,System.currentTimeMillis());com.ethk3.novaonepro.RetentionRulesSU2.pruneResearchGenomes(db);return 0;});
                    MainlineBridgeSU2.chooseIfDue(store,su2Seq);
                    CertificateSU2.maintain(store,su2Seq);
                    long su2Stop=Math.min(stop,SystemClock.elapsedRealtime()+20000);
                    while(!cancelled.get()&&SystemClock.elapsedRealtime()<su2Stop&&!SettlementExecutionGateR819.isActive()&&!RealtimePressureGateR811.isUnderPressure()){
                        String su2=ModelFoundryJobSU2.slice(store,su2Target);if(!su2.startsWith("SU2_GENERATION_DONE"))break;
                    }
                }
                long feedbackEnd=SystemClock.elapsedRealtime()+2000;
                for(int i=0;i<512&&!cancelled.get()&&SystemClock.elapsedRealtime()<feedbackEnd;i++){if(SettlementExecutionGateR819.isActive()||RealtimePressureGateR811.isUnderPressure()||!ResearchFeedbackSU1.drainOne(store))break;}
                final DbStore owner=store;
                long modelAuditStop=Math.min(stop,SystemClock.elapsedRealtime()+4000);
                while(!cancelled.get()&&SystemClock.elapsedRealtime()<modelAuditStop){
                    if(SettlementExecutionGateR819.isActive()||RealtimePressureGateR811.isUnderPressure())return;
                    if(!ModelAblationStoreSU1.advanceOne(store,new BudgetTokenSU1(2000,30000000,()->cancelled.get()||SettlementExecutionGateR819.isActive()||RealtimePressureGateR811.isUnderPressure())))break;
                }
                long auditStop=Math.min(stop,SystemClock.elapsedRealtime()+10000);
                while(!cancelled.get()&&SystemClock.elapsedRealtime()<auditStop){
                    if(SettlementExecutionGateR819.isActive()||RealtimePressureGateR811.isUnderPressure())return;
                    if(!CampaignAuditStoreSU1.advanceOne(store,new BudgetTokenSU1(2000,30000000,()->cancelled.get()||SettlementExecutionGateR819.isActive()||RealtimePressureGateR811.isUnderPressure())))break;
                }
                Models.Draw last=store.getLatestDraw();if(last!=null&&TargetIssueResolver.isValid(last.issue))store.coordinatorForResearchR952().runAtomicWriteOrThrowF01("SU1_DAILY_CLOSE",db->{LiveShadowLoopSU1.closeDays(db,Integer.parseInt(last.issue.substring(0,8)));return 0;});
                try(CampaignStateSU1 state=CampaignStateSU1.open(store)){
                    if(state==null){retry=false;return;}
                    while(!cancelled.get()&&!state.foundry.done()&&SystemClock.elapsedRealtime()<stop){
                        BudgetTokenSU1 budget=new BudgetTokenSU1(2000,30000000,()->cancelled.get()||SettlementExecutionGateR819.isActive()||RealtimePressureGateR811.isUnderPressure());
                        try{StrategyFoundrySU1.Attempt attempt=state.foundry.next(budget);state.checkpoint(attempt);}
                        catch(BudgetTokenSU1.Yield yielded){state.checkpoint(null);if(cancelled.get()||SettlementExecutionGateR819.isActive()||RealtimePressureGateR811.isUnderPressure())return;}
                    }
                    retry=!state.foundry.done();
                }
            }catch(RuntimeException failure){if(store!=null)StrategyRuntimeSU1.failure(store,"BURST_FAILED",failure);else android.util.Log.w("STARCORE_SU1","burst startup failed",failure);}
            finally{if(store!=null)store.close();RUNNING.set(false);finish(params,cancelled,retry);}
        });
        return true;
    }
    private void finish(JobParameters params,AtomicBoolean cancelled,boolean retry){new Handler(Looper.getMainLooper()).post(()->{if(active.remove(params,cancelled)&&!cancelled.get())jobFinished(params,retry);});}
    @Override public boolean onStopJob(JobParameters params){AtomicBoolean cancelled=active.remove(params);if(cancelled!=null)cancelled.set(true);return true;}
    @Override public void onDestroy(){for(AtomicBoolean c:active.values())c.set(true);worker.shutdown();super.onDestroy();}
}
